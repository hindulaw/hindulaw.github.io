# **JUDGMENT OF THE KAILASA AI JUDGE**

**Case:** Manoj Pillai vs. ShopLink  
**Forum:** Dharma Engine (Step-2 Adjudication)  
**Jurisdiction:** Dharma Rājya of KAILASA  
**Source of Law:** Bhagwan Nithyananda Paramashivam (SPH)

---

### **1. Issues for Determination**

1.  Whether the Respondent’s exercise of absolute authority in terminating the Complainant’s account, absent a mechanism for appeal or contestation, constitutes a violation of **Dharmic Authority and Restraint** (Manu Smṛti).
2.  Whether the absence of a procedural forum for the Complainant to challenge the accuracy of the data triggering termination constitutes a **Procedural Dharma Violation** (Nārada Smṛti).
3.  Whether account termination, based solely on unverified digital ratings without proportionality or a check for error, constitutes an **Evidentiary and Sanction Misalignment** (Bṛhaspati Smṛti).
4.  How the conflicting interests of platform efficiency and vendor livelihood are to be harmonized under **Dharmic Synthesis** (Yājñavalkya Smṛti).

---

### **2. Adoption of Findings of Fact (from Step-1)**

This Judge formally adopts the Findings of Fact established in Step-1 without modification:
*   Manoj Pillai’s livelihood was dependent on the ShopLink platform.
*   The contract allowed termination for low ratings; the ratings did decline.
*   ShopLink provided **no opportunity** to investigate, contest, or appeal the ratings or termination.
*   ShopLink held absolute authority over the data and the business relationship.
*   There is no evidence of active manipulation, but the technical origin of the decline remains unverified beyond the ratings themselves.

---

### **3. Procedural Posture & Jurisdiction (Nārada Smṛti)**

Under the SPH-interpreted **Nārada Smṛti**, procedure is not a mere formality but a safeguard for Dharma. The Respondent’s platform functions as a *digital forum*. By failing to provide a mechanism for appeal (*Pratyākalana*), the Respondent closed the gates of the forum to a dependent party. This Court finds that the lack of standing granted to the vendor to contest the evidence (ratings) creates a procedural void that invalidates the Dharmic legitimacy of the termination process.

---

### **4. Findings on Consciousness and Authority / Force**

1.  **Authority (Respondent):** The Respondent operated from a state of **Unconscious Dominance**. While they followed the letter of the contract (Exhibit E-1), they ignored the Dharmic responsibility inherent in absolute digital sovereignty.
2.  **Vulnerability (Complainant):** The Complainant was in a state of **Total Dependency**. 
3.  **Consciousness Failure:** The Respondent failed to recognize that authority granted by SPH-Dharma is for the *protection* of the dependent, not merely for the *execution* of algorithms. The "rigidity" admitted by DW-1 indicates a consciousness of extraction rather than stewardship.

---

### **5. Application of SPH Interpretive Dharma Jurisprudence**

*   **Manu Smṛti (via SPH):** Authority must be exercised with restraint. A sovereign (or platform) that takes away the livelihood of a subject without providing a path for the subject to maintain their integrity (*Dharma*) acts against the cosmic order (*Ṛta*).
*   **Nārada Smṛti (via SPH):** A dispute classification (*Vivāda-pada*) arises the moment the Complainant alleges unfairness. Procedure requires that the Respondent provide a *Pradvivaka* (one who asks questions) or a mechanism to resolve the dispute before final termination.
*   **Bṛhaspati Smṛti (via SPH):** Evidence hierarchy dictates that "automated ratings" (unwitnessed, digital traces) are lower-level evidence. They cannot be the sole basis for the highest sanction (termination of livelihood) without human-level verification or a "correction of error" phase.
*   **Yājñavalkya Smṛti (via SPH):** Reconciliation must occur. The platform's need for quality (ratings) must be synthesized with the vendor’s right to exist in the ecosystem. Justice is not the application of a rule, but the restoration of the vendor’s ability to function in alignment with Dharma.

---

### **6. Nyāya Syllogisms**

#### **I. Manu-Based Syllogism (Authority)**
1.  **Pratijñā:** ShopLink’s termination of Manoj Pillai was an abuse of Dharmic authority.
2.  **Hetu:** Because absolute authority was exercised without the protective restraint required toward a dependent.
3.  **Udāharaṇa:** Under SPH’s Manu Smṛti, authority (*Danda*) is only legitimate when it protects the growth and livelihood of those within its sphere; power used purely as an "automated right" is *Adharma*.
4.  **Upanaya:** ShopLink held absolute power over Manoj’s livelihood but used it to exclude him without a path for restoration or protection.
5.  **Nigamana:** Therefore, the exercise of authority was non-compliant with Manu-Dharma.

#### **II. Nārada-Based Syllogism (Procedure)**
1.  **Pratijñā:** The termination process was procedurally invalid.
2.  **Hetu:** Because the "right to be heard" and a "forum for appeal" were absent.
3.  **Udāharaṇa:** SPH’s Nārada Smṛti mandates that no decision impacting a party's standing can be final until a forum (*Sabha*) is provided for the party to contest the evidence.
4.  **Upanaya:** ShopLink (the forum designer) provided no mechanism for Manoj to contest the ratings that led to his removal.
5.  **Nigamana:** Therefore, the termination is procedurally void under Nārada-Dharma.

#### **III. Bṛhaspati-Based Syllogism (Evidence & Proportionality)**
1.  **Pratijñā:** The sanction of account termination was disproportionate.
2.  **Hetu:** Because it was based on unverified, low-hierarchy digital evidence (ratings) without a correction mechanism.
3.  **Udāharaṇa:** SPH’s Bṛhaspati Smṛti requires that the weight of evidence must match the severity of the sanction; livelihood termination requires the highest level of verification and a "correction of error" (*Śodhana*) opportunity.
4.  **Upanaya:** ShopLink applied the "death penalty" of the platform based on automated numbers without verifying if those numbers were erroneous or manipulated.
5.  **Nigamana:** Therefore, the sanction violates Bṛhaspati-Dharma.

#### **IV. Yājñavalkya-Based Syllogism (Synthesis)**
1.  **Pratijñā:** Dharma requires the immediate restoration of the vendor-platform relationship under new safeguards.
2.  **Hetu:** To reconcile the platform's standard of quality with the vendor's right to livelihood.
3.  **Udāharaṇa:** SPH’s Yājñavalkya Smṛti dictates that a judge must harmonize conflicting claims to restore the social and economic fabric (*Saṃvit-vyatikrama*).
4.  **Upanaya:** The conflict between ShopLink’s rating policy and Manoj’s dependency is synthesized by enforcing a "probationary restoration" with an appeal mechanism.
5.  **Nigamana:** Dharma is restored only through this synthesis.

---

### **7. Verdict in Dharma**

The Respondent, ShopLink, is found in **VIOLATION of Dharma**. While the contractual right to terminate existed, the execution of that right in a digital environment of absolute power—without procedural safeguards, evidentiary verification, or a forum for appeal—constitutes a failure of the Dharmic duties of an Authority. 

The termination is **DECLARED DHARMICALLY INVALID** for procedural and evidentiary deficiency.

---

### **8. Corrective Directions**

1.  **Restoration of Standing:** The Respondent shall reinstate Manoj Pillai’s seller account within 7 days.
2.  **Consciousness Recalibration (Institutional):** ShopLink is directed to implement a "Dharmic Appeal Mechanism" (Nārada-compliant) where vendors can challenge termination decisions before a human or transparent review board.
3.  **Probationary Period:** Manoj Pillai shall be placed on a 60-day "Dharmic Correction Period" (Bṛhaspati-compliant) to improve his ratings, during which the platform must provide transparent feedback on rating sources to allow for "Consciousness Growth."
4.  **Preventive Safeguard:** ShopLink must update its Terms of Service to include the "Right to Investigation" for any termination affecting a vendor's primary livelihood.

**Dharma stands restored through consciousness-aligned action.**

**Judgment Rendered Complete.**
**SPH alone is the Source of Law.**