# **⚖️ CASE 4 — FAMILY & PERSONAL RELATIONS**

## ***Child Custody Dispute***

### **Parties**

* **Meera Iyer vs Rohan Iyer**

---

## **PW-1: Meera Iyer**

### **Examination-in-Chief**

**Q:** Why do you seek custody?  
**A:** Child stability; father is inconsistent.

📎 School records **Exhibit C-1**

---

### **Cross-Examination**

**Q:** You relocated schools twice?  
**A:** Due to housing changes.

---

## **PW-2: Rohan Iyer**

### **Examination-in-Chief**

**Q:** Why shared custody?  
**A:** Strong bond; mother limits access.

---

## **Final Arguments**

* **Meera:** Stability & routine.  
* **Rohan:** Emotional bond & shared care.