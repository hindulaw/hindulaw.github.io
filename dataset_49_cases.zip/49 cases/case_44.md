# ⚖️ CASE 44 — AUTHORITY / GOVERNANCE ABUSE

## *Discretion vs Favoritism*

### Parties

* **Complainant:** Transport Permit Applicants Group
* **Respondent:** Permit Allocation Officer

### Facts

Applicants allege permits were granted to a small subset without transparent criteria. Officer claims discretionary selection based on “experience.”

### Evidence

* Permit list (Exhibit G-1)
* Applicant profiles (Exhibit G-2)

### Witnesses

* **PW-1:** Applicant Representative
* **DW-1:** Permit Officer

### Trial Highlights

* **Cross of DW-1:** No written scoring system or evaluation notes.

### Final Arguments

* **Complainant:** Discretion used selectively.
* **Respondent:** Expertise-based judgment.
