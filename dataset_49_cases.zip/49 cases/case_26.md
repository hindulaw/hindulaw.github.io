# ⚖️ CASE 26 — FAMILY & PERSONAL RELATIONS

## *Parental Alienation Allegation*

### Parties

* **Parent A:** Rhea Kapoor
* **Parent B:** Saurabh Kapoor

### Facts

Saurabh alleges Rhea discourages child from contact and speaks negatively about him. Rhea denies and cites scheduling issues.

### Evidence

* Messages scheduling visits (Exhibit F-1)
* Child counselor note (neutral) (Exhibit F-2)

### Witnesses

* **PW-1:** Saurabh
* **DW-1:** Rhea
* **PW-2:** Counselor

### Trial Highlights

* **Counselor:** Child expresses mixed feelings; no clear coaching found.

### Final Arguments

* **Saurabh:** Pattern of obstruction.
* **Rhea:** Practical constraints, not alienation.

