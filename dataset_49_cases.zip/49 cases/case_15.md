# ⚖️ CASE 15 — CRIMINAL (NON-VIOLENT)

## *Loan Disguised as Partnership*

### Parties

* **Complainant:** Alok Bansal
* **Accused:** Deepak Khurana

### Facts (Complaint)

Alok transferred funds believing it was a loan repayable in 6 months. Deepak claims it was a partnership contribution with risk.

### Response

Deepak produces messages referencing “joint venture”; denies any repayment promise.

### Evidence

* Bank transfers (Exhibit P-1)
* Messages referencing “returns” (Exhibit P-2)

### Witnesses

* PW-1 Alok
* DW-1 Deepak

### Trial Highlights

* **PW-1 (Chief):** “He assured fixed returns.”
* **Cross:** No written loan agreement.
* **DW-1 (Chief):** “Risk was explained.”
* **Cross:** No partnership deed.

### Final Arguments

* **Prosecution:** Substance over label—loan intent shown.
* **Defence:** Investment risk accepted; no deception.
