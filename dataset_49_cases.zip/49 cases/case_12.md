# **⚖️ CASE 12 — CRIMINAL (NON-VIOLENT)**

## ***Business Failure vs Deception***

### **Parties**

* **Complainant:** Farah Ali  
* **Accused:** Imran Sheikh

### **Facts**

Investment sought for startup. Business collapsed within 6 months.

### **Evidence**

* Pitch deck  
* Expense statements

### **Trial Issue**

Risk disclosure vs misrepresentation.

### **Final Arguments**

* **Prosecution:** Unrealistic assurances  
* **Defence:** Known business risk
