# **⚖️ CASE 14 — CRIMINAL (NON-VIOLENT)**

## ***Investment Inducement***

### **Parties**

* **Complainant:** Group of Investors  
* **Accused:** Pankaj Sood

### **Facts**

Investors claim false profit projections induced investment.

### **Evidence**

* Promotional materials  
* Investor messages

### **Trial Focus**

Opinion vs factual promise.

### **Final Arguments**

* **Prosecution:** Assured returns implied  
* **Defence:** Forecasts, not guarantees
