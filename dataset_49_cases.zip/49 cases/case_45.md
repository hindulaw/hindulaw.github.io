# ⚖️ CASE 45 — MIXED / EDGE CASE

## *Consent Later Withdrawn*

### Parties

* **Complainant:** Shalini Bose
* **Respondent:** Arjun Mehra

### Facts

Shalini agreed to transfer funds to Arjun during a relationship for a shared venture. After breakup, she alleges consent was emotional and seeks recovery. Arjun claims informed consent throughout.

### Evidence

* Transfer records (Exhibit E-1)
* Messages expressing agreement and later regret (Exhibit E-2)

### Witnesses

* **PW-1:** Shalini
* **DW-1:** Arjun

### Trial Highlights

* **Cross of PW-1:** Acknowledges messages saying “I’m okay with this.”
* **Cross of DW-1:** Admits venture never materialized.

### Final Arguments

* **Complainant:** Consent vitiated by emotional dependence.
* **Respondent:** Regret ≠ invalid consent.
