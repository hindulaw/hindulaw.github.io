# ⚖️ CASE 46 — MIXED / EDGE CASE

## *Civil–Criminal Overlap*

### Parties

* **Complainant:** Startup Investor — Keshav Arora
* **Respondent:** Founder — Nitin Paul

### Facts

Keshav invested funds expecting equity. Nitin used funds for expenses unrelated to business. Nitin claims broad authority to allocate funds.

### Evidence

* Investment email thread (Exhibit E-1)
* Expense statements (Exhibit E-2)

### Witnesses

* **PW-1:** Keshav
* **DW-1:** Nitin

### Trial Highlights

* **Cross of DW-1:** No clear approval for personal expenses.

### Final Arguments

* **Complainant:** Misuse of funds crosses into wrongdoing.
* **Respondent:** Business discretion; civil dispute only.
