# ⚖️ CASE 19 — CRIMINAL (NON-VIOLENT)

## *Misuse of Trust*

### Parties

* **Complainant:** Elderly Client Group
* **Accused:** Care Manager Neha Sethi

### Facts

Neha had access to client funds for expenses; excess withdrawals alleged.

### Evidence

* Withdrawal logs (Exhibit P-1)
* Expense notes (Exhibit D-1)

### Witnesses

* PW-1 Client Representative
* DW-1 Neha

### Trial Highlights

* **Cross of DW-1:** Receipts incomplete.

### Final Arguments

* **Prosecution:** Entrustment + excess = misuse.
* **Defence:** Poor record-keeping, no intent.
