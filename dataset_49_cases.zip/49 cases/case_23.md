# ⚖️ CASE 23 — CRIMINAL (VIOLENT / THREAT)

## *Self-Defence Claim*

### Parties

* **Victim:** Rohit Malhotra
* **Accused:** Dev Arjun

### Facts

Rohit alleges Dev struck him during a street dispute. Dev claims Rohit advanced aggressively and he pushed Rohit away to protect himself.

### Evidence

* Minor injury report (Exhibit P-1)
* Bystander statements (conflicting)

### Witnesses

* **PW-1:** Rohit
* **PW-2:** Bystander
* **DW-1:** Dev

### Trial Highlights

* **PW-2:** Saw argument; unsure who initiated contact.
* **Cross of DW-1:** Admits pushing with force.

### Final Arguments

* **Prosecution:** Force exceeded necessity.
* **Defence:** Proportionate response to imminent threat.
