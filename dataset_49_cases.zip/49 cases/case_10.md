
---

# **⚖️ CASE 10 — CIVIL / SERVICE & EMPLOYMENT**

## ***Supervisor Change → Sudden Discipline***

### **Parties**

* **Complainant:** Aman Verma  
* **Respondent:** New Supervisor Panel

### **Facts**

After supervisor change, Aman received warnings within 30 days for issues previously tolerated.

### **Evidence**

* Prior performance reviews  
* New warning notices

### **Trial Issue**

Consistency vs abrupt disciplinary shift.

### **Final Arguments**

* **Aman:** Arbitrary change in standards  
* **Respondent:** Reset expectations allowed
