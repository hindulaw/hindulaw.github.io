# ⚖️ CASE 33 — PROPERTY & CONTRACT

## *Quality Dispute*

### Parties

* **Plaintiff:** Nova Interiors
* **Defendant:** TimberCraft Suppliers

### Facts

Nova alleges delivered materials failed quality specs. TimberCraft claims specs were met.

### Evidence

* Purchase order specs (Exhibit P-1)
* Inspection photos (Exhibit P-2)

### Witnesses

* **PW-1:** Nova Site Engineer
* **DW-1:** TimberCraft QC Lead

### Trial Highlights

* **Cross of PW-1:** No third-party test conducted.
* **Cross of DW-1:** Internal QC only.

### Final Arguments

* **Plaintiff:** Visual defects evident.
* **Defendant:** No independent proof of defect.
