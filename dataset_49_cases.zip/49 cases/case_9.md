

# **⚖️ CASE 9 — CIVIL / SERVICE & EMPLOYMENT**

## ***Micromanagement vs Negligence***

### **Parties**

* **Complainant:** Sneha Kapoor  
* **Respondent:** Vikram Joshi

### **Facts**

Sneha claims constant checking of minor tasks amounts to harassment. Vikram claims prior errors justified oversight.

### **Evidence**

* Daily reporting logs  
* Error correction emails

### **Trial Focus**

Whether scrutiny was corrective or excessive.

### **Final Arguments**

* **Sneha:** Control destroyed autonomy  
* **Vikram:** Past negligence required supervision
