# ⚖️ CASE 32 — PROPERTY & CONTRACT

## *Delivery Delay*

### Parties

* **Plaintiff:** Orion Retail
* **Defendant:** Apex Logistics

### Facts

Orion alleges delayed delivery caused stockouts. Apex cites port congestion beyond control.

### Evidence

* Delivery schedule (Exhibit P-1)
* Delay notices (Exhibit D-1)

### Witnesses

* **PW-1:** Orion Supply Manager
* **DW-1:** Apex Operations Head

### Trial Highlights

* **Cross of DW-1:** No alternate routing attempted.
* **Cross of PW-1:** Buffer stock reduced before peak season.

### Final Arguments

* **Plaintiff:** Delay avoidable.
* **Defendant:** External disruption unavoidable.
