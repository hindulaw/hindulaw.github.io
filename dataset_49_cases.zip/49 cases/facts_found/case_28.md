### 1. Admitted Facts
* **Marriage and Co-habitation:** It is admitted that Priti Joshi and Akash Joshi are spouses who lived together.
* **Financial Monitoring:** Akash Joshi admits to the monitoring of expenses (Exhibit F-2/Cross-examination).
* **Existence of Conflict:** Both parties admit to the occurrence of verbal arguments and disagreements.
* **Emotional Distress:** It is admitted (via PW-2) that Priti Joshi exhibited signs of emotional distress during the timeline of the marriage.

### 2. Disputed Facts
* **Nature of Communication:** Priti alleges persistent belittling; Akash asserts these were mutual arguments typical of a marriage.
* **Isolation:** Priti alleges a pattern of isolation from social or external support; Akash denies this.
* **Intent of Financial Monitoring:** Priti characterizes the monitoring as "control"; Akash characterizes it as "shared expense management."

### 3. Contradictions Identified
* **External Contradiction:** Priti describes a unilateral environment of belittling and control, whereas Akash describes a bilateral environment of mutual disagreement.
* **Behavioral Contradiction:** Akash admits to monitoring expenses but denies that this constitutes a form of control or cruelty.
* **Silence/Reporting:** Priti alleges persistent distress but did not file contemporaneous reports or complaints during the periods of alleged belittling (Material Contradiction).

### 4. Resolution of Contradictions
* **Financial Oversight:** The contradiction regarding financial management is resolved by Akash’s own admission. While he labels it "monitoring," the act of scrutinizing a partner's expenditures matches the material definition of financial control.
* **Absence of Complaints:** The lack of contemporaneous complaints by Priti is resolved by the context of the domestic relationship. Fear of escalation or the desire to maintain the marital unit often explains the delay in reporting distress to outside authorities.
* **Witness Corroboration:** The contradiction regarding the severity of the conflict is resolved by PW-2, whose observation of emotional distress supports Priti's account of the impact of the environment over Akash’s account of "standard" arguments.

### 5. Credibility Findings
* **Priti Joshi (PW-1):** Credible. Her account of distress is corroborated by an independent witness (PW-2) and the admitted evidence of financial monitoring.
* **Akash Joshi (DW-1):** Partially Credible. While he admits to specific actions (monitoring), his characterization of the relationship as "mutual" is less consistent with the observed emotional state of the complainant reported by third parties.
* **Friend (PW-2):** High Credibility. As a third party, they provided an external observation of distress without an established personal incentive to misrepresent the emotional state of the complainant.

### 6. Power & Vulnerability Findings
* **Financial Authority:** Akash Joshi held the position of authority regarding the household's financial transparency and scrutiny, as evidenced by his monitoring of expenses.
* **Emotional Vulnerability:** Priti Joshi occupied a position of vulnerability, evidenced by the observed emotional distress and the lack of a contemporaneous platform to voice grievances.
* **Control Dynamics:** The pattern of monitoring expenses combined with reported isolation indicates a dominance-dependency dynamic rather than a partnership of equals.

### 7. Findings of Fact (FINAL)
* **Fact 1:** Akash Joshi actively monitored and scrutinized Priti Joshi’s financial expenditures.
* **Fact 2:** Priti Joshi suffered significant and observable emotional distress during the course of the marriage.
* **Fact 3:** Communication between the parties involved a pattern of belittling behavior directed toward Priti Joshi.
* **Fact 4:** Priti Joshi did not seek outside intervention or file formal complaints at the time the events were occurring.
* **Fact 5:** The domestic environment was characterized by a power imbalance where one party (Akash) exercised oversight that restricted the autonomy of the other (Priti).

**Findings of Fact (FINAL)**