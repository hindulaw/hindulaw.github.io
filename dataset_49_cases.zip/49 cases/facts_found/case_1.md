### **1. Admitted Facts**

*   **Managerial Relationship:** Anita Rao was the manager of Nikhil Varma.
*   **Performance Issues:** Nikhil Varma occasionally missed project deadlines.
*   **Supervision Methods:** Anita Rao monitored Nikhil Varma's work closely, sent emails demanding explanations for work issues (Exhibit C-1), and provided feedback to him during team meetings.
*   **Procedural History:** No formal written warnings were issued to Nikhil Varma regarding his performance prior to the implementation of intensive monitoring and late-night communications.
*   **Reporting Delay:** Nikhil Varma did not file a formal complaint through official channels immediately when the behavior began.

### **2. Disputed Facts**

*   **The Intent of Supervision:** Whether the monitoring was a legitimate effort to address team performance or an intentional effort to intimidate the complainant.
*   **The Nature of Communication:** Whether the feedback given in meetings was constructive professional guidance or public criticism intended to embarrass.
*   **The Severity of Impact:** Whether the supervision resulted in clinical anxiety and sleep deprivation or if the complainant is demonstrating exaggerated sensitivity to standard workplace pressure.

### **3. Contradictions Identified**

*   **Managerial Process Contradiction (External):** The respondent claims the supervision was a response to performance concerns, yet admits to skipping the standard professional step of issuing written warnings before escalating to intensive monitoring and public feedback.
*   **Scope Contradiction (Internal):** The respondent claims performance concerns existed "across the team," yet the evidence focused on the specific, intensive monitoring of the complainant, including late-night demands for explanations.

### **4. Resolution of Contradictions**

*   **Procedural Resolution:** The absence of written warnings before the escalation of monitoring indicates that the respondent’s actions were not following a standard corrective path. This supports the conclusion that the supervision style was reactive and personal rather than systemic and professional.
*   **Performance vs. Method:** While the complainant’s missed deadlines are admitted, the shift to public criticism and late-night messaging is inconsistent with a standard "performance concern" resolution, suggesting the method of supervision was disproportionate to the admitted performance issues.

### **5. Credibility Findings**

*   **Nikhil Varma:** Found to be highly credible. He admitted to his own lapses (missing deadlines), which suggests an absence of fabrication. His explanation for the delay in reporting (fear of retaliation) is consistent with the behavior of a subordinate in a high-pressure environment.
*   **Anita Rao:** Found to be partially credible regarding the existence of performance issues, but less credible regarding the justification of her methods. Her admission that she bypassed written warnings undermines the claim that her actions were standard "managerial control."

### **6. Power & Vulnerability Findings**

*   **Authority:** As manager, Anita Rao held absolute structural authority over the complainant’s daily work environment, performance reviews, and professional reputation.
*   **Dependency:** Nikhil Varma was dependent on the respondent for his professional standing and felt a high degree of vulnerability regarding his job security.
*   **Dominance:** The use of public meetings for criticism and late-night messaging indicates an exercise of dominance that extends beyond the professional workday.
*   **Retaliation Risk:** A credible fear of retaliation existed, which explains why the complainant endured the situation without immediate formal protest.

### **7. Findings of Fact (FINAL)**

*   The respondent, Anita Rao, utilized her position of authority to bypass formal disciplinary procedures (written warnings) and moved directly to a high-pressure supervision model.
*   This model included public criticism in front of peers and communication outside of standard working hours.
*   The complainant, Nikhil Varma, did have occasional performance lapses, but these were used as the basis for a system of monitoring that lacked professional boundaries.
*   The respondent's choice to criticize the complainant in team meetings rather than private sessions constitutes a public exercise of power rather than a corrective managerial action.
*   The intensive monitoring and communication style resulted in genuine psychological distress for the complainant.
*   The complainant’s delay in reporting the situation was a direct result of the power imbalance and the inherent risk of retaliation within the reporting structure.

**Findings of Fact (FINAL)**