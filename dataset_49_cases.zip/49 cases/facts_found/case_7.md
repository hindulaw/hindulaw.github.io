### **1. Admitted Facts**

*   Priya Sen and Aman Khanna were in a relationship.
*   Priya Sen sent messages (Exhibit C-1) that indicate agreement or consent to the decisions/actions in question at the time they occurred.
*   Decisions were made and acted upon during the course of the relationship.

### **2. Disputed Facts**

*   Whether the consent expressed in Exhibit C-1 was genuine or the result of external/internal pressure.
*   The existence, nature, and extent of the "financial pressure" cited by Priya Sen.
*   The existence, nature, and extent of the "emotional pressure" cited by Priya Sen.
*   Whether the decisions were truly "mutual," as asserted by Aman Khanna.

### **3. Contradictions Identified**

*   **Internal Contradiction (Priya Sen):** A material contradiction exists between Priya Sen’s contemporary written communications (Exhibit C-1), which show agreement, and her current testimony, which disputes that agreement.
*   **External Contradiction (Priya Sen vs. Aman Khanna):** Priya Sen claims the decisions were a result of pressure; Aman Khanna claims they were mutual. This is a material contradiction regarding the nature of the interaction.

### **4. Resolution of Contradictions**

*   The contradiction between the messages (Exhibit C-1) and the current testimony is resolved by identifying the timing: the messages represent the state of the relationship at the time of the acts, while the testimony represents a retrospective re-evaluation. 
*   Because the record contains the physical evidence of the agreement (Exhibit C-1) but lacks specific evidence or instances of the "financial pressure" (such as bank statements, debts, or specific threats), the contemporary record of agreement is the established behavior, while the claim of pressure remains an uncorroborated assertion.

### **5. Credibility Findings**

*   **Priya Sen:** Credibility is affected by the shift in narrative. While emotional and financial pressures are valid human experiences that can influence behavior, the lack of specific detail regarding how this pressure was applied makes the transition from "agreement" to "dispute" appear retrospective.
*   **Aman Khanna:** Credibility is supported by the alignment between his testimony and the available documentary evidence (Exhibit C-1). His account of "mutuality" is consistent with the documented conduct of the parties at the time.

### **6. Power & Vulnerability Findings**

*   Priya Sen identifies herself as being in a position of financial and emotional dependency. This suggests a perceived or actual vulnerability that could lead to "compliance" rather than "consent."
*   Aman Khanna is positioned as the party who did not experience this pressure, placing him in a position of relative stability or authority within the relationship dynamic.
*   The record confirms a claim of vulnerability (financial/emotional), but does not contain evidence of Aman Khanna actively exploiting that vulnerability through specific coercive acts.

### **7. Findings of Fact (FINAL)**

*   During the relationship, decisions were made that Priya Sen agreed to, as evidenced by her own messages in Exhibit C-1.
*   Priya Sen now characterizes that agreement as the result of financial and emotional pressure.
*   Aman Khanna acted on the basis that the decisions were mutual and consented to.
*   The record establishes that agreement was communicated and documented at the time of the events.
*   The record does not provide specific instances, documents, or evidence of the mechanics of the financial or emotional pressure that would demonstrate the agreement was involuntary.
*   The change in Priya Sen’s stance occurred after the period of the relationship/decisions in question.

**Findings of Fact (FINAL)**