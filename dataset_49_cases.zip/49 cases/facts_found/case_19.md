### 1. Admitted Facts
*   Neha Sethi was employed as the Care Manager for the Elderly Client Group.
*   In her role, Neha Sethi was granted direct access to and control over client funds for the purpose of paying expenses.
*   Withdrawals were made from the client funds, as evidenced by withdrawal logs (Exhibit P-1).
*   The receipts and records corresponding to the withdrawals are incomplete (Admitted by DW-1 during cross-examination).

### 2. Disputed Facts
*   The specific purpose and destination of the "excess" withdrawals—funds withdrawn that do not have corresponding receipts.
*   Whether the lack of documentation is a result of administrative oversight (poor record-keeping) or a deliberate act of diverting funds.

### 3. Contradictions Identified
*   **External Contradiction:** There is a mismatch between the total volume of currency withdrawn (Exhibit P-1) and the total value of documented expenses (Exhibit D-1). (Classification: **Material**)
*   **Internal Contradiction:** The Accused (DW-1) maintains that funds were used for client expenses while simultaneously admitting she cannot provide the documentation to prove those specific expenses occurred. (Classification: **Material**)

### 4. Resolution of Contradictions
*   The contradiction between funds withdrawn and funds documented is resolved by the physical evidence: money left the account that is not accounted for in the expense notes.
*   The defense's explanation of "poor record-keeping" does not negate the fact that a discrepancy exists; it confirms that the Accused cannot account for the delta between withdrawals and expenditures.

### 5. Credibility Findings
*   **Consistency:** The Accused’s testimony is inconsistent with the basic professional requirements of a fiduciary role (Care Manager).
*   **Incentive:** The Accused has a significant incentive to categorize the missing funds as "poor record-keeping" to avoid the implication of personal gain.
*   **Natural Human Behavior:** It is not aligned with standard professional behavior for a person managing the funds of vulnerable individuals to fail to keep receipts for "excess" withdrawals.

### 6. Power & Vulnerability Findings
*   **Authority:** Neha Sethi held the position of authority and held the "keys" to the financial resources.
*   **Vulnerability/Dependency:** The Complainant (Elderly Client Group) was in a position of dependency, relying entirely on the Accused for the honest management of their daily financial needs.
*   **Dominance:** The Accused had sole control over the record-keeping process, creating a transparency gap that the vulnerable party could not easily bridge.

### 7. Findings of Fact (FINAL)
*   Neha Sethi was the sole individual responsible for the management and withdrawal of the Elderly Client Group's funds.
*   Funds were withdrawn from the clients' accounts in amounts exceeding the documented expenses.
*   Neha Sethi failed to maintain or produce receipts for these excess withdrawals.
*   A material discrepancy exists between the money taken out and the money proven to be spent on the clients.
*   The Accused occupied a position of trust and power over a vulnerable, dependent group and failed to provide an accounting for the funds removed from their possession.

**Findings of Fact (FINAL)**