### **1. Admitted Facts**

*   A contract exists between Zenith Builders and Coastal Suppliers, identified as Exhibit C-1.
*   The contract contains a force majeure clause.
*   A delay in the supply of materials occurred.
*   The delay resulted in project losses and financial penalties for Zenith Builders.

---

### **2. Disputed Facts**

*   The specific nature and extent of the "supply chain disruption" cited by the Defendant.
*   Whether the delay was caused by factors within or outside the Defendant's control.

---

### **3. Contradictions Identified**

*   **Internal Contradictions:** None identified. Both witnesses remained consistent with their primary positions.
*   **External Contradictions (Material):** There is a contradiction in the characterization of the delay. PW-1 characterizes the delay as a straightforward failure causing loss, while DW-1 characterizes the same delay as an unavoidable result of external disruptions.

---

### **4. Resolution of Contradictions**

*   The contradiction regarding the "justification" of the delay is resolved by the material evidence: both parties agree the delay happened and that a force majeure clause exists. 
*   The Project Manager (PW-1) admits the existence of the force majeure clause, which acknowledges that certain delays may be excused under the contract. 
*   The Supplier Director (DW-1) attributes the delay to supply chain disruption but provides no specific evidence on the record to refute the impact of the delay stated by PW-1.
*   The facts show a causal chain: External disruption (Fact 1) led to a delay (Fact 2), which led to project penalties (Fact 3).

---

### **5. Credibility Findings**

*   **PW-1 (Project Manager):** High credibility. Their testimony regarding project loss is consistent with the role of a manager. Their admission of the force majeure clause—which potentially favors the opposing party—suggests a high level of factual honesty.
*   **DW-1 (Supplier Director):** Moderate credibility. As a director, they have direct knowledge of supply chains; however, they have a high incentive to attribute delays to "external" factors to mitigate the consequences of the delay.

---

### **6. Power & Vulnerability Mapping**

*   **Authority:** Coastal Suppliers held the power of performance; Zenith Builders was dependent on Coastal Suppliers to meet their own external deadlines.
*   **Vulnerability:** Zenith Builders bore the primary vulnerability regarding third-party penalties. They were in a position of dependency on the defendant's delivery schedule to avoid financial harm.
*   **Risk:** The risk of loss was borne by the Plaintiff, while the risk of supply volatility was borne by the Defendant.

---

### **7. Findings of Fact (FINAL)**

*   Zenith Builders and Coastal Suppliers entered into a formal agreement (Exhibit C-1).
*   The agreement included a specific provision (Force Majeure) for excusing delays under certain external conditions.
*   Coastal Suppliers did not deliver materials according to the project timeline.
*   The cause of this failure was a disruption in the supply chain.
*   As a direct result of the materials not arriving on time, Zenith Builders incurred documented project losses and was subjected to penalties.

**Findings of Fact (FINAL)**