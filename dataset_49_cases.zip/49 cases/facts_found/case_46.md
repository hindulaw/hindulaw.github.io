### 1. Admitted Facts
* Keshav Arora (Complainant) provided investment funds to Nitin Paul (Respondent).
* The intended purpose of the fund transfer was for Keshav Arora to receive equity in Nitin Paul’s startup.
* Nitin Paul received and exercised control over these funds.
* A portion of the invested funds was utilized by Nitin Paul for expenses that were not related to the operations or growth of the business.
* An investment email thread (Exhibit E-1) exists documenting the communication between the parties.
* Expense statements (Exhibit E-2) exist detailing the outflow of the funds.

### 2. Disputed Facts
* Whether Nitin Paul possessed the authority to allocate investment capital toward personal or non-business expenses.
* Whether the "broad authority" claimed by Nitin Paul was communicated to or agreed upon by Keshav Arora at the time of investment.
* Whether the expenses identified as "unrelated to business" were essential for the founder’s maintenance or were a diversion of capital.

### 3. Contradictions Identified
* **External Contradiction:** Keshav Arora asserts the funds were strictly for business growth and equity; Nitin Paul asserts he had the discretion to use the funds for non-business purposes.
* **Internal Contradiction (Respondent):** During the cross-examination of DW-1, Nitin Paul claimed authority to allocate funds but could not identify or produce any specific approval or communication where such personal/non-business use was authorized by the investor.
* **Classification:** These contradictions are **Material**, as the case centers entirely on whether the funds were used according to the agreed-upon purpose.

### 4. Resolution of Contradictions
* The contradiction regarding authority is resolved in favor of the record (Exhibit E-1 and Cross-examination). In a standard investment-for-equity transaction, funds are inherently tied to the entity in which equity is held. 
* Nitin Paul’s claim of "broad authority" is unsupported by the material on record. The absence of documentation or verbal approval for personal expenses during the cross-examination indicates that the "authority" was a unilateral assumption by the Respondent rather than a bilateral agreement.

### 5. Credibility Findings
* **Keshav Arora (PW-1):** High credibility. His position aligns with the standard behavior of a startup investor expecting capital to be used for business growth to protect his equity value.
* **Nitin Paul (DW-1):** Low credibility regarding the use of funds. His inability to substantiate the claim of "discretion" for personal expenses during cross-examination, paired with the expense statements (Exhibit E-2), suggests an incentive to recharacterize fund diversion as "business discretion" after the fact.

### 6. Power & Vulnerability Findings
* **Authority:** Nitin Paul held the position of authority as the Founder with direct control over the bank accounts and the day-to-day allocation of capital.
* **Vulnerability:** Keshav Arora, as the investor, occupied a position of vulnerability once the funds were transferred. He was dependent on Nitin Paul’s transparency and honesty, as he no longer had physical control over the capital.
* **Risk:** The risk of dominance was present, as the founder utilized his operational control to divert funds without seeking the consent of the capital provider.

### 7. Findings of Fact (FINAL)
1. Keshav Arora invested capital into Nitin Paul’s startup specifically for equity.
2. The investment email thread (Exhibit E-1) established a professional investment relationship.
3. Nitin Paul diverted a portion of the investment funds to personal or non-business expenses (Exhibit E-2).
4. Nitin Paul did not have prior, clear, or documented approval from Keshav Arora to use investment funds for non-business purposes.
5. Nitin Paul used his position as the person in control of the startup's finances to allocate funds for his own benefit.
6. The claim of "broad discretion" was an after-the-fact justification and was not a term of the original agreement.

**Findings of Fact (FINAL)**