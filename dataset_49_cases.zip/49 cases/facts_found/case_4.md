### 1. Admitted Facts
*   The child has experienced two school relocations (Admitted by Meera Iyer).
*   These relocations were a direct result of changes in housing (Admitted by Meera Iyer).
*   School records exist documenting the child’s history (Exhibit C-1).
*   Both parties acknowledge a parental relationship and an ongoing dispute regarding the child's living arrangements and care.

### 2. Disputed Facts
*   The consistency of Rohan Iyer’s involvement in the child’s life.
*   The nature and strength of the emotional bond between Rohan Iyer and the child.
*   Whether Meera Iyer actively limits Rohan Iyer’s access to the child.
*   Whether the child’s current environment provides sufficient stability.

### 3. Contradictions Identified
*   **External Contradiction (Material):** Meera Iyer characterizes Rohan Iyer as "inconsistent," while Rohan Iyer claims a "strong bond" and seeks "shared care."
*   **External Contradiction (Material):** Meera Iyer asserts she provides "stability," whereas Rohan Iyer implies the current arrangement is restrictive and the record shows multiple school/housing changes under her care.

### 4. Resolution of Contradictions
*   The characterization of "inconsistency" vs. "strong bond" reflects a difference in perspective regarding parental presence. However, the admitted fact of two school relocations due to housing changes provides objective evidence that the child’s physical routine has been disrupted while in Meera’s primary care.
*   Rohan’s claim that access is limited explains his lack of "consistency" from his perspective, suggesting that his perceived inconsistency may be a result of external restriction rather than personal choice.

### 5. Credibility Findings
*   **Meera Iyer:** Credible regarding the fact of relocations; she did not attempt to hide the instability of the child's schooling. Her focus is on "routine," though her actions (moving twice) suggest a struggle to maintain that routine.
*   **Rohan Iyer:** His request for "shared custody" rather than "sole custody" suggests a credible acknowledgment of the necessity of the mother’s role, lending weight to his claim of wanting a genuine emotional bond rather than total control.

### 6. Power & Vulnerability Findings
*   **The Child:** Holds the highest level of vulnerability, being dependent on both parents for emotional and environmental stability.
*   **Meera Iyer:** Holds primary situational power, as she has dictated the child’s housing and schooling locations and currently controls the degree of access allowed to the father.
*   **Rohan Iyer:** Displays a position of dependency regarding his relationship with the child, as his access is currently mediated or limited by Meera.

### 7. Findings of Fact (FINAL)
*   The child has undergone two changes in schooling and housing.
*   Meera Iyer is the primary decision-maker regarding the child’s current residence and education.
*   Rohan Iyer desires a shared caregiving role but currently experiences limited access to the child.
*   There is a conflict between the mother’s goal of "stability" and the actual physical relocations that have occurred.
*   There is a conflict between the father’s claim of a "strong bond" and the mother’s claim of his "inconsistency."