### 1. Admitted Facts
* Penalties were issued to a specific subset of vendors (Exhibit G-1).
* Other vendors engaged in the same conduct/violations as those penalized (Exhibit G-2).
* No written criteria or documented protocol exists to explain the selection process for enforcement (DW-1 testimony).

### 2. Disputed Facts
* Whether the selection of specific vendors for penalties was based on "operational sequencing" or "arbitrary targeting."
* Whether there was a pre-existing plan to eventually penalize all violators in a specific order.

### 3. Contradictions Identified
* **Internal Contradiction (Respondent):** The Respondent claims a systematic "phased enforcement" approach; however, the Respondent also admits there are no written criteria for how these phases or selections are determined (Material).
* **External Contradiction:** The Complainant provides evidence of contemporaneous non-penalized violations (Exhibit G-2), which contradicts the Respondent’s implied duty of uniform enforcement during a shift or period.

### 4. Resolution of Contradictions
* The "phased enforcement" claim is unsupported by documentation. In the absence of written criteria, "operational sequencing" is indistinguishable from subjective selection. 
* The contradiction between the claim of a systematic phase and the lack of a written plan is resolved in favor of the Complainant; without a plan, the "phases" are reactive or discretionary rather than structural.

### 5. Credibility Findings
* **Complainant (PW-1):** High. The testimony is supported by physical evidence (Exhibit G-2) showing identical unpunished violations, establishing a factual baseline of inconsistency.
* **Respondent (DW-1):** Low regarding the defense of "sequencing." The admission that no written criteria exist undermines the claim that the selection was part of a legitimate, pre-planned operational sequence. The incentive to label discretionary choices as "phasing" after the fact is high to avoid charges of bias.

### 6. Power & Vulnerability Findings
* **Authority:** The Enforcement Supervisor holds absolute discretionary power over which vendors receive penalties, directly impacting their financial survival.
* **Dependency:** The vendors are highly dependent on the Supervisor’s decisions.
* **Risk:** The lack of written criteria creates an environment where vendors are vulnerable to personal bias, as there is no objective standard to verify why one vendor is penalized while a neighbor is not.

### 7. Findings of Fact (FINAL)
* Penalties were applied to some vendors while others, committing the same acts, were ignored.
* The Enforcement Supervisor had no objective, written, or transparent system for selecting which vendors to penalize.
* There is no material evidence—only verbal assertion—that a "phased enforcement" plan existed prior to the filing of the complaint.
* The selection process was based entirely on the subjective discretion of the Enforcement Supervisor.
* The result was an inconsistent application of enforcement across the market.

**Findings of Fact (FINAL)**