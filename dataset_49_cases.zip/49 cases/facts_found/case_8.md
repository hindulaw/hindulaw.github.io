### **1. Admitted Facts**
* Ritesh Malhotra (PW-1) is a Senior Analyst reporting to Kavita Deshmukh (DW-1), the Department Head.
* Task allocations were recorded in spreadsheets (Exhibit C-1).
* There is no formal, written workload policy governing the department.
* There is no rotation system in place for the distribution of tasks among team members (Admitted by DW-1).
* Internal email communications exist regarding task assignments and timelines (Exhibit C-2).

### **2. Disputed Facts**
* Whether the workload assigned to Ritesh was objectively disproportionate compared to his peers.
* Whether the increase in tasks was a reaction to Ritesh questioning timelines (retaliatory) or based on his specific expertise (skill-based).
* Whether the workload caused Ritesh to suffer from burnout.

### **3. Contradictions Identified**
* **External Contradiction:** DW-1 claims task allocation was "skill-based," yet PW-1 and PW-2 testify to a pattern of unequal burden that does not align with a balanced team structure.
* **Internal Contradiction (DW-1):** DW-1 asserts assignments were fair/discretionary while simultaneously admitting that no rotation system or objective policy exists to ensure such fairness.
* **Classification:** These contradictions are **Material**, as the lack of an objective system is the core mechanism through which unequal distribution occurs.

### **4. Resolution of Contradictions**
* **Policy vs. Discretion:** The admission by DW-1 that no rotation system or formal policy exists resolves the dispute in favor of the Complainant's observation. In the absence of an objective framework, "managerial discretion" resulted in a measurable imbalance in the task spreadsheets (C-1).
* **Timing of Assignments:** The evidence in C-1 and C-2 correlates the increase in assignments with the period immediately following Ritesh’s questioning of timelines. This temporal link resolves the "skill-based" vs. "punitive" contradiction by showing a shift in conduct triggered by a specific event.

### **5. Credibility Findings**
* **PW-1 (Ritesh):** High. His testimony is consistent with the documentary evidence (C-1) and is corroborated by a peer witness (PW-2).
* **PW-2 (Co-worker):** High. As a peer, PW-2 has no direct incentive to support the Complainant but provides external validation of the workload disparity.
* **DW-1 (Kavita):** Moderate to Low. While DW-1 admits to the lack of a system, the justification of "skill-based" allocation lacks supporting documentation or a defined skill-matrix, appearing as an after-the-fact rationalization for unequal distribution.

### **6. Power & Vulnerability Findings**
* **Authority:** DW-1 holds absolute authority over task distribution, performance reviews, and timeline management.
* **Dependency:** PW-1 is professionally dependent on DW-1.
* **Vulnerability:** PW-1 is vulnerable to "workload dumping" because there are no formal policy safeguards (as admitted by DW-1) to which a subordinate can appeal when seeking a balanced workload. The power dynamic allows for the use of workload as a pressure tool without immediate oversight.

### **7. Findings of Fact (FINAL)**
* Ritesh Malhotra was assigned a significantly higher volume of tasks compared to his peers, as evidenced by Exhibit C-1.
* The department operated without any formal workload policy or objective task-rotation mechanism.
* The workload assigned to Ritesh increased specifically after he raised concerns regarding project timelines.
* The Respondent (Kavita Deshmukh) exercised subjective discretion in assignments which resulted in an unequal burden on the Complainant.
* The sustained disproportionate workload led to the Complainant's exhaustion and burnout.