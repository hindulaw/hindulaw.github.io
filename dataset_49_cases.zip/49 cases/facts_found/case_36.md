### 1. Admitted Facts
*   A written sale agreement (Exhibit P-1) exists between Aarav Constructions (Plaintiff) and Maya Kulkarni (Defendant).
*   The completion of the clubhouse was delayed (Admitted by PW-1).
*   The Defendant has occupied the premises on an intermittent basis (Admitted by DW-1).
*   Aarav Constructions offered possession of the premises to the Defendant.

### 2. Disputed Facts
*   Whether the construction of the primary residential unit is fully complete according to the specifications in the sale agreement.
*   Whether the amenities, other than the clubhouse, are complete or functional.
*   The total amount of payment currently outstanding versus the amount already paid.
*   Whether the "intermittent" occupancy constitutes a formal acceptance of the property in its current state.

### 3. Contradictions Identified
*   **External Contradiction:** The Plaintiff asserts that the payment obligation is independent of delays, implying the project is sufficiently ready for final settlement. However, the Defendant produces progress photos (Exhibit D-1) and the Plaintiff’s own witness (PW-1) admits to a delay in the clubhouse, contradicting a claim of total project readiness.
*   **Internal Contradiction (Defendant):** The Defendant alleges that construction delays and incomplete amenities justify non-payment, yet she has physically utilized the premises (intermittent occupancy).

**Classification:**
*   **Material:** The delay in the clubhouse and the status of completion (Material).
*   **Material:** The intermittent occupancy of the unit (Material, as it relates to the usability of the core structure).

### 4. Resolution of Contradictions
*   **Occupancy vs. Incompleteness:** The contradiction regarding the Defendant's occupancy is resolved by the fact that a residential unit can be "habitable" (allowing for intermittent use) while the "project" as a whole (including contracted amenities like a clubhouse) remains "incomplete."
*   **Project Readiness:** The contradiction regarding completion is resolved in favor of the Defendant’s claim of incompleteness, corroborated by the Plaintiff's admission (PW-1) and photographic evidence (D-1).

### 5. Credibility Findings
*   **PW-1 (Project Manager):** High credibility regarding the delay. As an employee of the Plaintiff, admitting to a delay in the clubhouse is a statement against interest, which is generally indicative of truth.
*   **DW-1 (Maya Kulkarni):** Moderate to High credibility. Her admission of intermittent occupancy shows a lack of intent to hide her usage of the property, despite her claim that the contract has not been fully honored by the developer.

### 6. Power & Vulnerability Findings
*   **Authority:** Aarav Constructions, as the developer, holds the position of authority regarding the construction schedule, the quality of materials, and the control over the common amenities (clubhouse).
*   **Dependency:** Maya Kulkarni is in a position of dependency. She has committed capital via a sale agreement and is dependent on the developer to fulfill the specific promises of the contract to realize the value of her investment.
*   **Risk:** The Defendant faces the risk of possessing an asset that does not meet the contracted value, while the Plaintiff faces the financial risk of non-payment for work already performed on the residential unit itself.

### 7. Findings of Fact (FINAL)
1.  A valid sale agreement governs the relationship between the parties.
2.  The residential unit is in a condition that allows for intermittent physical occupancy.
3.  The project is factually incomplete regarding the promised amenities, specifically the clubhouse.
4.  The Defendant is currently withholding payment based on the perceived gap between the contracted project scope and the actual physical state of the project.
5.  Construction progress at the site is not currently in full alignment with the "promised completion" referenced in the sale agreement.

**Findings of Fact (FINAL)**