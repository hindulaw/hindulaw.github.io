### 1. Admitted Facts
*   A financial transaction occurred where the Complainant (Pooja Nair) paid the Accused (Kunal Arora) for specific services (Exhibit P-1).
*   The promised services were never delivered to the Complainant.
*   The Accused’s account was the recipient of the funds.
*   Communication between both parties regarding the transaction took place via digital chat (Exhibit P-2).

### 2. Disputed Facts
*   Whether the Accused had actual control of the digital account at the exact time the payment was received and the service was due.
*   Whether the Accused made a genuine attempt to refund the Complainant.
*   The specific timing of the "account compromise" relative to the transaction in question.
*   Whether a third party was responsible for the communication and non-delivery of services.

### 3. Contradictions Identified
*   **External Contradiction (Account Status):** The Accused (DW-1) claims the account was compromised at the time of the transaction. However, the Platform Support Agent (PW-2) testified that the account was only flagged at a later time, suggesting it was functioning normally during the Complainant's interaction. (**Material**)
*   **Internal/External Contradiction (Refund Claim):** The Accused (DW-1) claims he attempted a refund. However, there is no digital evidence, receipt, or log entry to support this claim, which contradicts his own testimony regarding his intent to return the money. (**Material**)

### 4. Resolution of Contradictions
*   **Regarding Account Control:** The testimony of the Platform Support Agent (PW-2) is prioritized over the Accused’s claim. Digital platform logs are objective records; since the flagging occurred "later," it is determined that the account was under the Accused's control during the transaction.
*   **Regarding the Refund:** In digital financial systems, every "attempt" leaves a digital footprint. The total absence of proof for a refund (as noted in the cross-examination of DW-1) resolves this contradiction against the Accused. No refund attempt was made.

### 5. Credibility Findings
*   **Pooja Nair (PW-1):** High credibility. Her testimony is supported by material evidence (P-1 and P-2) and aligns with the natural behavior of a consumer who paid for a service and received nothing.
*   **Platform Support Agent (PW-2):** High credibility. As a third-party professional with access to system logs, they have no incentive to misrepresent the timing of the account flag.
*   **Kunal Arora (DW-1):** Low credibility. His claims of third-party misuse and refund attempts are unsupported by any material evidence. His incentive to avoid responsibility for the missing funds is high.

### 6. Power & Vulnerability Findings
*   **Authority/Control:** The Accused (Kunal Arora) held the position of power as the party in possession of both the funds and the means to deliver the service. 
*   **Dependency/Vulnerability:** The Complainant (Pooja Nair) was in a position of vulnerability, having relinquished her money in exchange for a promise, leaving her entirely dependent on the Accused’s integrity for the fulfillment of the contract.

### 7. Findings of Fact (FINAL)
*   Pooja Nair paid Kunal Arora for services.
*   Kunal Arora received the payment into his account.
*   The services were not provided.
*   Kunal Arora was in control of his account and the communication logs at the time the payment was received and the service was withheld.
*   Kunal Arora did not attempt to refund the money.
*   The claim of a third-party compromise is a post-facto explanation that does not align with the platform's technical logs.
*   Kunal Arora retained the Complainant's funds without providing the agreed-upon value or returning the money.

**Findings of Fact (FINAL)**