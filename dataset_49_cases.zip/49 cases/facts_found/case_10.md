### **1. Admitted Facts**
*   Aman Verma is an employee who was previously under a different supervisor.
*   A New Supervisor Panel assumed authority over Aman Verma.
*   Prior to the supervisor change, Aman Verma’s performance reviews did not result in the disciplinary actions currently in question.
*   Within 30 days of the New Supervisor Panel taking over, Aman Verma was issued formal warning notices.
*   The behaviors/issues cited in the new warnings were known or present during the previous supervisor’s tenure but were tolerated or not formally disciplined.

### **2. Disputed Facts**
*   Whether the New Supervisor Panel communicated a change in standards or a "reset" of expectations to Aman Verma before issuing the warnings.
*   Whether the standards applied by the New Supervisor Panel are consistent with general company policy or represent a personalized shift in expectations.
*   Whether the timing of the warnings (within 30 days) allowed for a reasonable adjustment period to the new management style.

### **3. Contradictions Identified**
*   **External Contradiction (Material):** There is a direct contradiction between the "Prior Performance Reviews" and the "New Warning Notices." The record shows the same conduct was rated as acceptable/tolerable in the past but is now classified as a disciplinary offense.
*   **Internal Contradiction (Respondent):** The Respondent claims a right to "reset expectations," yet the record shows they issued "warnings" rather than "notices of new policy." A warning typically implies a violation of a known standard, whereas a reset implies the establishment of a new one.

### **4. Resolution of Contradictions**
*   The contradiction between past reviews and current warnings is resolved by the change in personnel. The conduct of the employee remained consistent; the threshold for discipline shifted. 
*   The record indicates that the "reset" described by the Respondent was implemented through punitive measures (warnings) rather than administrative communication (policy updates).

### **5. Credibility Findings**
*   **Aman Verma:** His claim of an arbitrary shift is consistent with the material evidence (the 30-day timeline and the contrast between old reviews and new warnings). His account aligns with natural human behavior when facing a sudden change in workplace culture.
*   **New Supervisor Panel:** Their claim of "resetting expectations" is a credible management motive; however, the lack of evidence showing a prior announcement of these new standards before issuing warnings suggests a prioritized incentive to discipline rather than to correct.

### **6. Power & Vulnerability Findings**
*   **Authority:** The New Supervisor Panel holds absolute structural authority over Aman Verma’s employment status and professional record.
*   **Dependency:** Aman Verma is in a position of dependency, relying on the supervisors for his livelihood and career progression.
*   **Vulnerability:** The 30-day window is a period of high vulnerability for an employee. The abrupt shift in standards without a documented transition period created a situation where the employee was penalized for behaviors that were previously established as "safe" by the employer.

### **7. Findings of Fact (FINAL)**
*   Aman Verma’s conduct did not fundamentally change during the transition between supervisors.
*   The New Supervisor Panel implemented a higher or different standard of discipline than the previous supervisor.
*   Formal warnings were issued to Aman Verma within 30 days of the new management's arrival.
*   The issues cited in the warnings were previously tolerated or considered acceptable under the prior supervisor's recorded reviews.
*   There is no evidence on record that the New Supervisor Panel provided Aman Verma with a clear, non-disciplinary notice of the "reset expectations" prior to the issuance of the formal warnings.
*   The disciplinary shift was abrupt and predicated on a change in management's tolerance levels rather than a new decline in the employee’s performance.

**Findings of Fact (FINAL)**