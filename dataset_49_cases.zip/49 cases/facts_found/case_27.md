### 1. Admitted Facts
*   Parent A (Meenal Shah) has received a formal job offer, as verified by Exhibit F-1 and the testimony of the Employer HR (PW-2).
*   Meenal Shah intends to relocate for the purpose of accepting this employment.
*   Meenal Shah acknowledges that the relocation will result in a decrease in the frequency of in-person visitation between Parent B (Harish Shah) and the child.
*   Harish Shah opposes the relocation.
*   Harish Shah possesses flexible work hours, as admitted during cross-examination.
*   A proposed visitation plan (Exhibit F-2) exists, created by Meenal Shah to address the change in access.

### 2. Disputed Facts
*   The extent to which economic stability derived from the new employment impacts the child’s quality of life compared to the impact of reduced physical proximity to Harish Shah.
*   The adequacy of the proposed visitation plan (Exhibit F-2) in mitigating the disruption of the relationship between Harish Shah and the child.

### 3. Contradictions Identified
*   **External Contradiction (Material):** There is a material contradiction between the parties regarding the primary driver of the child’s well-being. Meenal Shah asserts that economic stability is the primary factor, while Harish Shah asserts that the continuity of the physical relationship outweighs economic gain.
*   **External Contradiction (Immaterial):** None identified. The witnesses (PW-1, PW-2, PW-3) are in agreement regarding the tangible facts (the job offer and the flexible schedule).

### 4. Resolution of Contradictions
*   The contradiction regarding the child's well-being cannot be resolved as a "falsehood" vs "truth" because both parties are presenting subjective valuations of the child’s needs. 
*   However, the material fact established is that the relocation creates a mandatory trade-off: an increase in financial resources (verified by PW-2) in exchange for a decrease in physical presence (admitted by PW-1). 
*   The fact of Harish Shah’s flexible work hours is resolved as true, providing a potential mechanism for visitation, though it does not negate the fact of increased distance.

### 5. Credibility Findings
*   **Meenal Shah (PW-1):** High credibility. She openly admitted that the move would reduce in-person visits, showing no intent to deceive the fact-finder regarding the negative consequences of her plan.
*   **Employer HR (PW-2):** High credibility. As a neutral third party, their confirmation of the job offer establishes the economic reality of the move as a fact.
*   **Harish Shah (PW-3):** High credibility. His admission of flexible work hours, which could potentially undermine his argument for total opposition, suggests honesty regarding his personal circumstances.

### 6. Power & Vulnerability Findings
*   **The Child:** The child is the primary vulnerable party, holding no authority over the geographic location of their residence and remaining dependent on the economic provisions of Meenal and the emotional/physical presence of both parents.
*   **Meenal Shah:** Holds the power of the "initiator." Her decision to move dictates the changing circumstances for all other parties.
*   **Harish Shah:** Is in a position of dependency regarding the child’s current geographic proximity. His flexible work hours indicate a high level of availability but do not grant him the power to stop the relocation of the other parent.

### 7. Findings of Fact (FINAL)
1.  A valid and confirmed employment opportunity exists for Meenal Shah in a different location.
2.  The relocation is motivated by a pursuit of economic stability for the household.
3.  The relocation will definitively cause a reduction in the current frequency of in-person contact between Harish Shah and the child.
4.  Harish Shah has the temporal flexibility to engage in non-standard visitation schedules due to his work hours.
5.  Both parents are acting based on a genuine desire to preserve their respective contributions to the child (economic vs. relational), with no evidence of bad faith or intent to harm the child’s interests.