**1. Admitted Facts**

*   **Missed Deadline:** Tara Singh (PW-1) admitted during cross-examination that she missed the project deadline.
*   **Usability of Work:** Rohan Gupta (DW-1) admitted during cross-examination that the work provided by Tara, while allegedly incomplete, was "usable."
*   **Withholding of Payment:** Rohan Gupta admitted to withholding payment from Tara.
*   **Contractual Relationship:** Both parties admit to a professional engagement for design services, evidenced by Invoices (E-1) and Project Messages (E-2).

**2. Disputed Facts**

*   **Degree of Completion:** Tara asserts "substantial performance"; Rohan asserts "non-completion."
*   **Impact of Delay:** The extent to which the missed deadline invalidated the utility of the project.
*   **Payment Entitlement:** Whether the delivered work warrants the full invoice amount or allows for a total withholding of funds.

**3. Contradictions Identified**

*   **Internal Contradiction (Rohan Gupta):** Rohan claims "non-completion" justifies zero payment, yet admits the work received was "usable." (Material)
*   **Internal Contradiction (Tara Singh):** Tara claims entitlement to payment based on performance while admitting she breached the agreed-upon delivery schedule. (Material)
*   **External Contradiction:** Tara’s messages and claims suggest the project was effectively finished; Rohan’s messages and claims suggest the project was insufficient for his needs. (Material)

**4. Resolution of Contradictions**

*   **Resolution of Completion/Usability:** The contradiction between "non-completion" and "usable work" is resolved by the admission of the Respondent. If work is usable, the claim that it is "incomplete" to the point of being worthless is factually incorrect.
*   **Resolution of Performance Claim:** Tara’s claim of full performance is resolved by her own admission of a missed deadline. Performance was partial or delayed, not "substantial" in the context of the original agreement's timeline.
*   **Truth of Conduct:** Both parties have provided an "overstated" version of the facts to serve their financial interests (Tara overstating completion; Rohan overstating the failure).

**5. Credibility Findings**

*   **Tara Singh:** Credibility is diminished regarding the "completeness" of her service due to the admitted deadline breach. She has a high incentive to minimize the delay to secure payment.
*   **Rohan Gupta:** Credibility is diminished regarding the "failure" of the project due to his admission that the work was usable. He has a high incentive to exaggerate the deficiency to justify retaining funds.
*   **General Behavior:** Both parties exhibit a pattern of selective truth-telling common in commercial disputes where financial leverage is at stake.

**6. Power & Vulnerability Findings**

*   **Authority:** Rohan Gupta held financial authority as the payor. He exercised this power by unilaterally withholding funds for work he admitted was usable.
*   **Vulnerability:** As a freelance designer, Tara Singh occupied a position of financial dependency. Once the labor was expended and the "usable" product handed over, she lost her primary leverage.
*   **Pattern of Conduct:** There is a pattern of "overstatement" from both sides. Rohan utilized the missed deadline as a pretext to withhold all payment, while Tara utilized the "usable" nature of the work to downplay her breach of the timeline.

**7. Findings of Fact (FINAL)**

1.  A professional agreement for design services existed between Tara Singh and Rohan Gupta.
2.  Tara Singh failed to meet the contractually agreed-upon deadline.
3.  Tara Singh delivered work to Rohan Gupta that was not 100% complete according to the original specifications.
4.  Rohan Gupta received and accepted work from Tara Singh that he found to be "usable."
5.  Rohan Gupta withheld the entirety of the payment despite the admitted utility of the work.
6.  Both parties intentionally misrepresented the severity of the situation in their initial claims: the Complainant ignored the material impact of the delay, and the Respondent ignored the material value of the assets received.