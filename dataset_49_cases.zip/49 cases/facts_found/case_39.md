### 1. Admitted Facts
*   **Existence of Contract:** Both parties admit to entering into an "Agreement to Sell" (Exhibit P-1) regarding the property.
*   **Payment of Earnest Money:** It is admitted that Karan Oberoi paid earnest money to Sunita Malhotra.
*   **Timing of Financing:** Karan Oberoi admits that his loan sanction letter arrived late.
*   **Subsequent Marketing:** Sunita Malhotra admits to marketing the property to other potential buyers shortly after the dispute over the deadline arose.

### 2. Disputed Facts
*   **Cause of Breach:** Karan alleges Sunita "backed out" of the deal in bad faith; Sunita alleges Karan defaulted by failing to arrange funds by the stipulated deadline.
*   **Readiness and Willingness:** Karan claims he was still capable of completing the purchase despite the delay; Sunita claims the failure to meet the deadline terminated his right to the property.

### 3. Contradictions Identified
*   **Internal Contradiction (Plaintiff):** Karan claims Sunita acted in bad faith by backing out, yet admits his own loan sanction—the mechanism for payment—was late. (Material)
*   **External Contradiction:** Karan characterizes the failed transaction as the seller "backing out," while Sunita characterizes it as the buyer "defaulting." (Material)

### 4. Resolution of Contradictions
*   **Financing Delay:** The contradiction regarding the cause of the failed transaction is resolved by the bank correspondence (Exhibit D-1) and Karan’s own admission. The primary disruption to the timeline was the late arrival of the loan sanction.
*   **Seller's Actions:** Sunita’s admission of marketing the property to others "soon after" the deadline indicates that she treated the contract as immediately terminated upon Karan’s failure to secure funds, rather than allowing for a grace period.

### 5. Credibility Findings
*   **Karan Oberoi:** His credibility regarding "readiness" is diminished by the admitted delay in his loan sanction. While he alleges bad faith on the part of the seller, the material record shows he did not have the necessary funds at the time specified.
*   **Sunita Malhotra:** Her testimony is consistent with the timeline of the bank correspondence. However, her incentive to move on to other buyers quickly suggests she was strictly enforcing the deadline to either keep the earnest money or seek a better offer.

### 6. Power & Vulnerability Findings
*   **Financial Dependency:** Karan was in a position of dependency on a third party (the bank). His ability to perform was contingent on external institutional speed.
*   **Asset Control:** Sunita held the position of authority as the owner of the asset and the holder of the earnest money. Once the deadline passed, she held the power to either extend the timeline or declare a default.
*   **Market Dynamics:** The fact that Sunita marketed the property "soon after" suggests she did not feel vulnerable but rather was positioned to take advantage of the market immediately upon the expiration of the deadline.

### 7. Findings of Fact (FINAL)
*   An agreement existed between Karan and Sunita for the sale of property, supported by the payment of earnest money.
*   The agreement contained a deadline for the arrangement of funds and completion of the sale.
*   Karan failed to secure a bank loan sanction within the timeframe required to meet the payment deadline.
*   Sunita did not grant an extension and immediately began seeking other buyers once the deadline was missed.
*   The transaction failed primarily because the buyer’s financing was not secured on time, followed by the seller’s immediate decision to treat the contract as ended.

**Findings of Fact (FINAL)**