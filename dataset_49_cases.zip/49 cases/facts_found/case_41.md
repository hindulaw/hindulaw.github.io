### 1. Admitted Facts
*   Inspections were conducted by the Respondent at the Complainant’s manufacturing unit.
*   The frequency of these inspections was higher than the statistical average for similar units (Admitted by DW-1).
*   Production downtime occurred at the unit during the period of these inspections (Exhibit G-2).

### 2. Disputed Facts
*   Whether the inspections were motivated by legitimate, specific safety risks or by an intent to disrupt operations.
*   Whether the compliance requirements demanded by the Respondent were standard or "beyond norms."
*   The necessity of the "precautionary oversight" in relation to the specific conditions of the unit.

### 3. Contradictions Identified
*   **External Contradiction (Material):** The Respondent claims the inspections were "precautionary oversight" for safety (DW-1), while the Complainant claims they were "oppressive" and designed to pressure the unit (PW-1).
*   **Internal Contradiction (Material):** The Respondent maintains a stance of routine safety oversight but admits under cross-examination that the frequency of the visits deviated from established averages (DW-1).

### 4. Resolution of Contradictions
*   The contradiction regarding the purpose of the inspections is resolved by the lack of specific safety incident reports to justify the deviation from average frequency. 
*   Because the Respondent admitted the frequency was above average and the Complainant provided records of downtime (Exhibit G-2), the material reality aligns with the Complainant’s claim of disruption. The "precautionary" explanation lacks a documented trigger to explain the increased frequency.

### 5. Credibility Findings
*   **Complainant (PW-1):** High credibility. The claims of disruption are supported by objective downtime records (Exhibit G-2) and the Respondent's own admission of high inspection frequency.
*   **Respondent (DW-1):** Lower credibility regarding the "safety" justification. While the Respondent admits to the high frequency, they offer only a general "precautionary" defense without citing specific violations or risks at the unit that would necessitate a departure from average inspection intervals.

### 6. Power & Vulnerability Findings
*   **Authority:** The Inspection Officer (Respondent) holds significant regulatory power over the manufacturing unit, including the ability to halt production and demand compliance.
*   **Vulnerability:** The Small Manufacturing Unit (Complainant) is in a position of dependency. They must comply with the Inspector to remain operational, making them vulnerable to any abuse of the frequency of inspections.
*   **Risk:** There is a clear risk of dominance where the Respondent can use the "color of office" to cause economic hardship through repeated downtime.

### 7. Findings of Fact (FINAL)
*   The Respondent conducted inspections at a frequency that exceeded the standard norms for the industry.
*   These inspections resulted in measurable production downtime and operational disruption for the Complainant.
*   The Respondent did not provide evidence of specific safety hazards or incidents that justified the increased frequency of inspections at this specific unit.
*   The pattern of conduct demonstrates an exercise of authority that caused repeated interference with the Complainant's operations under the guise of safety oversight.