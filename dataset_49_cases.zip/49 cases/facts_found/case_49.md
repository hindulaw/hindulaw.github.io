### 1. Admitted Facts
*   Manoj Pillai (Complainant) operated as a vendor on the ShopLink platform.
*   The relationship was governed by platform terms (Exhibit E-1) which included provisions for termination based on rating thresholds.
*   Manoj Pillai’s seller account experienced a decline in customer ratings (Exhibit E-2).
*   Manoj Pillai admits that his ratings did, in fact, decline (PW-1).
*   ShopLink terminated Manoj Pillai’s seller account following the decline in ratings.
*   ShopLink provided no mechanism for vendors to appeal or contest account terminations (DW-1).

### 2. Disputed Facts
*   The cause of the rating decline: The Complainant alleges the ratings were manipulated; the Respondent asserts they were a reflection of performance.
*   The integrity of the rating data: Whether the ratings in Exhibit E-2 were organic or artificially influenced.

### 3. Contradictions Identified
*   **External Contradiction (Material):** Manoj Pillai alleges "manipulation" of ratings to trigger termination, while the Platform Policy Manager (DW-1) maintains the termination was a standard enforcement of contractual terms based on the rating history (Exhibit E-2).
*   **External Contradiction (Material):** The Complainant describes the process as "unfair" and "procedurally deficient," while the Respondent characterizes the same events as a "contractual right."

### 4. Resolution of Contradictions
*   Regarding the rating decline: Since the Complainant (PW-1) admitted during cross-examination that his ratings declined, the fact of the decline is established.
*   Regarding manipulation: There is no material evidence on record (such as technical logs, whistleblower testimony, or forensic data analysis) to support the allegation of active manipulation by the Respondent. The "manipulation" remains an allegation, while the "decline" is an admitted fact.
*   Regarding the appeal process: The contradiction between "standard enforcement" and "unfairness" is resolved by the admission of DW-1. It is a fact that while the contract allowed termination, the platform structure provided no avenue for the vendor to challenge the accuracy of the data triggering that termination.

### 5. Credibility Findings
*   **Manoj Pillai (PW-1):** Highly credible regarding the admission of declining ratings, as this was an admission against his own interest. His claim of livelihood destruction is consistent with the nature of platform dependency.
*   **Platform Policy Manager (DW-1):** Highly credible regarding the admission that no appeal mechanism existed, as this acknowledges a systemic rigidity in the Respondent's operations.
*   **Evidence (E-1 & E-2):** These are treated as accurate reflections of the platform’s state and rules at the time of the incident.

### 6. Power & Vulnerability Findings
*   **Authority:** ShopLink (Respondent) held absolute authority over the digital environment, the data (ratings), and the continuation of the business relationship. They functioned as the sole designer of the terms and the sole executor of the termination.
*   **Dependency/Vulnerability:** Manoj Pillai (Complainant) was in a position of high dependency, relying on the platform for his livelihood. 
*   **Risk:** The Complainant faced a total loss of income with no recourse or "voice" within the system (due to the lack of an appeal mechanism), creating a significant power imbalance where the Respondent could take terminal action without a check on data accuracy.

### 7. Findings of Fact (FINAL)
1.  Manoj Pillai’s livelihood was dependent on his seller account on ShopLink.
2.  The contract between the parties allowed ShopLink to terminate the account if ratings fell below a certain level.
3.  The ratings associated with Manoj Pillai’s account did decline below the threshold.
4.  ShopLink executed the termination of the account based strictly on the rating history.
5.  Manoj Pillai had no opportunity to investigate, contest, or appeal the ratings or the termination decision because the Respondent did not provide such a mechanism.
6.  The termination resulted in the cessation of Manoj Pillai’s business operations on the platform.
7.  While the Complainant alleges manipulation, the material on record confirms the *fact* of the decline and the *fact* of the termination, but contains no evidence explaining the technical origin of the decline beyond the ratings themselves.