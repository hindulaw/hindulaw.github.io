### **1. Admitted Facts**

*   A verbal argument took place in a street setting between Sameer Qureshi (PW-1) and a group of three individuals.
*   The argument escalated into a physical altercation.
*   Sameer Qureshi sustained minor physical injuries, as evidenced by Exhibit P-1.
*   The physical encounter was characterized by "chaos" (testimony of PW-2).
*   The numerical ratio of the encounter was three individuals against one.

### **2. Disputed Facts**

*   **Initiation:** Whether the physical violence was initiated by the group (assault) or if it began as a mutual scuffle.
*   **Manner of Conduct:** Whether Sameer Qureshi was intentionally "surrounded" to facilitate an attack or if the positioning was an incidental byproduct of a group argument.
*   **Specific Acts:** The identity of the specific individual(s) who landed the strikes that caused the injuries in Exhibit P-1.
*   **Aggression:** Whether there was a single primary aggressor or if the aggression was multi-directional.

### **3. Contradictions Identified**

*   **External (PW-1 vs. PW-2):** PW-1 claims a specific sequence of being surrounded and struck; however, the neutral bystander (PW-2) describes the scene as "chaos" where it was "unclear" who struck whom.
*   **External (PW-1 vs. DW-1):** PW-1 alleges a targeted assault; DW-1 alleges a "mutual scuffle."
*   **Internal (Prosecution Case):** The prosecution argues for "collective intimidation," yet their own independent witness (PW-2) states under cross-examination that there was "no clear aggressor."

### **4. Resolution of Contradictions**

*   **Regarding the Aggressor:** The contradiction between PW-1’s claim of being a victim of a targeted strike and PW-2’s observation of "chaos" is resolved in favor of a general state of disorder. Because a neutral witness (PW-2) could not discern a clear aggressor, the high-intensity nature of the scuffle likely obscured the specific origin of the first blow.
*   **Regarding the Scuffle:** The conflict between "assault" and "mutual scuffle" is resolved by the physical evidence (P-1) and the bystander testimony. The existence of injuries proves physical contact occurred, but the bystander’s inability to point to a primary aggressor supports the finding that the event was a disorganized brawl rather than a structured attack.

### **5. Credibility Findings**

*   **PW-1 (Sameer Qureshi):** Credibility is moderate. While his injuries are documented, his narrative of a clean, one-sided assault is not corroborated by the neutral witness (PW-2).
*   **DW-1 (Group Member):** Credibility is low/moderate due to an inherent incentive to characterize the event as "mutual" to avoid individual liability.
*   **PW-2 (Bystander):** Credibility is high. As a non-party with no identified stake in the outcome, their description of "chaos" and the inability to identify a clear aggressor is the most reliable account of the environment.

### **6. Power & Vulnerability Findings**

*   **Numerical Power:** A clear power imbalance existed due to the 3-on-1 ratio. Regardless of who started the verbal argument, Sameer Qureshi was in a position of physical vulnerability once the situation escalated.
*   **Environmental Context:** The street setting provided no immediate escape or protection for the lone individual against a group.
*   **Atmospheric Dominance:** The presence of a group of three against one individual naturally creates an environment of intimidation, regardless of whether a formal "plan" to surround the victim existed.

### **7. Findings of Fact (FINAL)**

1.  A verbal dispute occurred between Sameer Qureshi and a group of three men in a public street.
2.  The dispute transitioned into a physical altercation involving all parties present.
3.  The physical altercation was disorganized and chaotic, preventing neutral observers from identifying a primary initiator or specific strikers.
4.  Sameer Qureshi was numerically outnumbered (three against one) during the entirety of the physical event.
5.  Sameer Qureshi sustained minor injuries during this encounter.
6.  The material on record does not establish which of the three individuals in the group delivered the blows.
7.  The material on record does not establish a clear "first striker," but confirms a period of mutual physical engagement within a chaotic environment.

**Findings of Fact (FINAL)**