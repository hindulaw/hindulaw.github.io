### 1. Admitted Facts
*   A contractual relationship existed between Nova Interiors (Plaintiff) and TimberCraft Suppliers (Defendant) for the supply of materials.
*   Specific quality specifications were established and documented in the Purchase Order (Exhibit P-1).
*   Materials were delivered by TimberCraft Suppliers to Nova Interiors.
*   No independent or third-party testing was conducted on the materials by either party.
*   TimberCraft Suppliers conducted only internal Quality Control (QC) before delivery.

### 2. Disputed Facts
*   Whether the delivered materials met the technical specifications outlined in Exhibit P-1.
*   The significance and extent of the defects captured in the inspection photos (Exhibit P-2).
*   The actual physical condition and grade of the timber at the point of delivery.

### 3. Contradictions Identified
*   **External Contradiction (Material):** PW-1 (Nova Site Engineer) testifies that the materials failed to meet specifications, whereas DW-1 (TimberCraft QC Lead) testifies that all specifications were met.
*   **External Contradiction (Material):** The visual evidence of defects in the inspection photos (Exhibit P-2) contradicts the internal QC clearance asserted by DW-1.

### 4. Resolution of Contradictions
*   The contradiction between PW-1 and DW-1 regarding technical compliance cannot be resolved through technical data, as neither party provided objective third-party analysis.
*   The contradiction between the inspection photos (P-2) and the internal QC report is resolved in favor of the photos. Visual evidence (P-2) provides a direct representation of the material state, whereas the internal QC testimony (DW-1) is a subjective internal verification performed by the party interested in the sale.

### 5. Credibility Findings
*   **PW-1 (Nova Site Engineer):** Credibility is moderate. While the witness represents the buyer, their testimony is supported by contemporaneous photographic evidence (P-2).
*   **DW-1 (TimberCraft QC Lead):** Credibility is lower regarding the absolute quality of the goods. As the lead of the internal department responsible for the materials, there is a natural incentive to affirm the efficacy of their own QC process. The lack of external validation weakens the weight of this testimony against visual evidence of defects.
*   **Exhibit P-2 (Inspection Photos):** High credibility. These serve as a factual record of the material condition at the site, independent of the verbal assertions of either party.

### 6. Power & Vulnerability Findings
*   **Authority/Control:** TimberCraft Suppliers held total control over the selection, processing, and initial quality assessment of the materials prior to delivery.
*   **Vulnerability/Dependency:** Nova Interiors was dependent on the integrity of TimberCraft’s internal QC, as they would only be able to inspect the materials upon arrival.
*   **Information Asymmetry:** TimberCraft possessed full knowledge of the material origins and any issues during the manufacturing/treatment process that might not be immediately visible to a site engineer.

### 7. Findings of Fact (FINAL)
*   The parties agreed to specific material standards as per Exhibit P-1.
*   TimberCraft Suppliers delivered the materials based solely on their own internal quality assessments without external verification.
*   Upon arrival at the site, the materials exhibited visual defects that were documented in Exhibit P-2.
*   The presence of these documented visual defects indicates that the materials did not match the required state of quality at the time of inspection, regardless of the defendant’s internal QC clearance.
*   Neither party sought independent verification to confirm or deny the internal technical specifications.
*   The materials delivered contained visible physical deviations from the expected standard.