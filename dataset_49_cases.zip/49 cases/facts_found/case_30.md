### 1. Admitted Facts

*   **Relationship:** Alisha Verma and Rohit Verma are siblings with a shared dependent parent.
*   **Financial Need:** There is a documented need for financial support for the parent, evidenced by expense records (Exhibit F-1).
*   **Income Disparity:** There is a difference in the respective income capacities of the two parties (Exhibit F-2).
*   **Lack of Formality:** No formal, written, or legally binding cost-sharing agreement exists between the siblings regarding parental support.
*   **Discretionary Spending:** Rohit Verma acknowledges that he engages in discretionary spending (spending on non-essential items or activities).

### 2. Disputed Facts

*   **Definition of Capacity:** Whether Rohit’s financial contribution accurately reflects his maximum sustainable capacity or if he is intentionally withholding support.
*   **The Threshold of "Fairness":** Whether a "fair" contribution is defined by an equal 50/50 split or a proportional split based on respective income levels.
*   **Intent:** Alisha claims Rohit is "avoiding" responsibility; Rohit claims he is contributing according to his means.

### 3. Contradictions Identified

*   **External Contradiction (Rohit’s Position vs. Behavior):** Rohit claims "unequal income capacity" as a reason for limited contribution, yet acknowledges "discretionary spending" during cross-examination.
*   **Classification:** This is a **Material** contradiction. It goes to the core of whether the lack of contribution is a matter of *ability* (capacity) or *will* (choice).

### 4. Resolution of Contradictions

*   The contradiction regarding Rohit’s capacity is resolved by the admission of discretionary spending. While Exhibit F-2 may show a lower income relative to Alisha, the admission of discretionary spending confirms that Rohit possesses liquid funds that are not being allocated to the dependent parent. Therefore, his "capacity" is not at its absolute limit; rather, he is prioritizing personal spending over parental financial responsibility.

### 5. Credibility Findings

*   **Alisha Verma:** High credibility. She admitted to the lack of a formal agreement, a fact that does not inherently benefit her position, suggesting transparency regarding the history of the dispute.
*   **Rohit Verma:** Moderate-to-Low credibility regarding "financial incapacity." While his income may be lower, his admission of discretionary spending undermines the claim that he *cannot* contribute more. His defense of "capacity" is partially a self-serving interpretation of his budget rather than a fixed financial impossibility.

### 6. Power & Vulnerability Findings

*   **The Dependent Parent:** Holds the highest level of vulnerability. They are entirely dependent on the voluntary or negotiated contributions of their children and are not a party to the dispute but are the primary subject of its impact.
*   **The Siblings:** There is a power imbalance based on income. Alisha, likely having the higher income (implied by the complaint and Exhibit F-2), bears the primary financial burden but lacks the power to compel Rohit to pay without a formal agreement. Rohit holds "refusal power"—by not agreeing to a formal structure, he maintains control over his discretionary income at the expense of the shared responsibility.

### 7. Findings of Fact (FINAL)

*   A dependent parent requires financial assistance, which is currently being provided without a formal structure.
*   Alisha Verma is contributing a larger share of the financial support.
*   Rohit Verma earns less than Alisha Verma, but he possesses surplus funds beyond his basic needs, which he currently directs toward discretionary spending.
*   No prior agreement was established to define the specific percentages of contribution.
*   The tension arises from a discrepancy between Rohit’s actual available funds and his elected level of contribution toward the parent.

Findings of Fact (FINAL)