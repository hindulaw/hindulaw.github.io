### 1. Admitted Facts
*   The mother of the parties is elderly and requires medical care and regular appointments.
*   Care provided to the mother was inconsistent and medical appointments were missed.
*   The Respondent (Rajiv) was frequently unavailable due to travel.
*   The Complainant (Kamala) did not share updated medical schedules with the Respondent.
*   Communication regarding care took place via messaging (Exhibit F-2).

### 2. Disputed Facts
*   Whether the Respondent’s lack of presence constituted "neglect" or was a result of logistical coordination failures.
*   Whether the Complainant’s failure to share schedules was an act of "obstruction" or an administrative oversight.
*   The primary cause of the missed medical appointments.

### 3. Contradictions Identified
*   **Internal Contradiction (Complainant):** Kamala alleges a "pattern of neglect" by Rajiv, yet admits under cross-examination that she did not provide him with the updated schedules necessary to facilitate that care. (Material)
*   **External Contradiction (Parties vs. Nurse):** While Kamala frames the issue as neglect and Rajiv frames it as coordination failure, the Home Nurse (PW-2) identifies the root cause specifically as "scheduling disputes." (Material)

### 4. Resolution of Contradictions
*   The contradiction regarding the cause of missed appointments is resolved by the neutral testimony of the Home Nurse and Kamala’s own admission. The inconsistency in care was not a unilateral abandonment of duty, but a direct result of the breakdown in information sharing. 
*   Rajiv’s travel-related absence is a contributing factor to the lack of care, but it is functionally linked to the failure of the siblings to synchronize the schedule.

### 5. Credibility Findings
*   **PW-2 (Home Nurse):** Highly credible. As a third-party caregiver with no identified incentive to favor either sibling, her observation that care suffered due to "disputes" aligns with the material evidence.
*   **PW-1 (Kamala):** Credible regarding the fact that care was inconsistent, but her credibility is diminished regarding the allegation of "neglect" due to her admission of withholding essential scheduling information.
*   **DW-1 (Rajiv):** Credible regarding his travel and availability constraints; his claim of coordination failure is supported by the Complainant’s admissions and the Nurse’s testimony.

### 6. Power & Vulnerability Findings
*   **The Mother:** Highly vulnerable. She is entirely dependent on the cooperation of her children for her health and safety.
*   **The Siblings:** Both Kamala and Rajiv hold positions of authority over the mother’s care. There is a horizontal power struggle between them. 
*   **Vulnerability within the dispute:** By withholding schedules, Kamala held information power. By traveling, Rajiv created a dependency on Kamala for information, which was not met.

### 7. Findings of Fact (FINAL)
*   The elderly mother received inconsistent care and missed medical appointments.
*   Rajiv was physically absent for significant periods due to travel, reducing his capacity to provide direct care.
*   Kamala possessed the updated medical schedules but did not communicate them to Rajiv.
*   The failure to provide adequate care was caused by a total breakdown in communication and coordination between the two siblings.
*   The home environment was characterized by scheduling disputes that directly interfered with the Home Nurse’s ability to maintain a consistent care routine.
*   The material on record does not establish a unilateral abandonment of care, but rather a mutual failure to synchronize care duties.

**Findings of Fact (FINAL)**