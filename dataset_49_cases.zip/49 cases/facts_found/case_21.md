### 1. Admitted Facts
*   A dispute exists between Leena Thomas and Prakash Menon regarding a property.
*   A verbal confrontation took place between the two parties.
*   The confrontation involved "raised voices," as confirmed by a third-party witness (PW-2).
*   The interaction was characterized by heat or anger.

### 2. Disputed Facts
*   The specific words uttered by Prakash Menon during the confrontation.
*   Whether the words used were intended to convey a specific threat of physical harm or were merely expressions of frustration/anger.
*   The level of fear actually experienced by Leena Thomas at the moment of the encounter.

### 3. Contradictions Identified
*   **External Contradiction (Material):** There is a contradiction between the account of PW-1 (Leena), who alleges words implying harm, and the account of DW-1 (Prakash), who characterizes the speech as "heated words" without a threat.
*   **External Contradiction (Material):** PW-1’s assertion of a clear threat is not fully supported by PW-2 (Neighbor), who heard the volume and tone but could not confirm the specific content of the speech.

### 4. Resolution of Contradictions
*   Regarding the specific words used: The contradiction cannot be resolved in favor of a specific transcript of the event because the only neutral witness (PW-2) was unable to distinguish the exact vocabulary.
*   Regarding the nature of the event: The contradictions are resolved by the shared observation of a high-conflict verbal exchange. While the specific threat is unverified by a third party, the occurrence of an aggressive verbal confrontation is established.

### 5. Credibility Findings
*   **PW-2 (Neighbor):** Highly credible as a neutral party with no stated interest in the property dispute; however, the testimony is limited by physical distance or environmental factors (unclear words).
*   **PW-1 (Leena) & DW-1 (Prakash):** Both parties possess a high incentive to frame the facts in a way that favors their position in the underlying property dispute. 
*   **Consistency:** The testimony of all parties is consistent regarding the existence of a loud, emotionally charged argument.

### 6. Power & Vulnerability Findings
*   **Authority/Dependency:** There is no evidence of a structural or domestic power imbalance; however, the property dispute creates a state of mutual hostility.
*   **Vulnerability:** Leena Thomas expressed a sense of vulnerability (fear) arising from the verbal aggression.
*   **Conduct Pattern:** The dispute is centered on a specific material asset (property), which serves as the primary driver for the aggressive behavior of both parties.

### 7. Findings of Fact (FINAL)
*   A property dispute between Leena Thomas and Prakash Menon led to a face-to-face confrontation.
*   Prakash Menon engaged in a loud and aggressive verbal exchange with Leena Thomas.
*   The neighbor (PW-2) witnessed the aggressive tone and raised voices but could not verify the specific wording of the alleged threat.
*   Prakash Menon used language that was aggressive enough to be perceived by Leena Thomas as a threat of harm.
*   The verbal exchange was a direct result of the ongoing conflict over property, characterized by high emotional volatility and mutual aggression.

Findings of Fact (FINAL)