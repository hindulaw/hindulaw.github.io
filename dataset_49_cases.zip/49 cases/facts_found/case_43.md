**1. Admitted Facts**

*   Devika Nair served as an Internal Auditor.
*   Sameer Kulkarni served as Department Director and held authority over Devika Nair’s assignments.
*   Devika Nair submitted a report (Exhibit G-1) identifying irregular expense approvals within the department.
*   Following the submission of the report, Devika Nair was removed from her audit duties and assigned to clerical work (Exhibit G-2).
*   The reassignment occurred exactly one week after the submission of the audit report.

**2. Disputed Facts**

*   The motive behind the reassignment: The Complainant asserts it was retaliation for whistleblowing; the Respondent asserts it was a standard "team restructuring."
*   The necessity of the reassignment: Whether there was a legitimate administrative requirement to move an auditor to clerical tasks.

**3. Contradictions Identified**

*   **External Contradiction (Material):** DW-1 (Sameer Kulkarni) claims the reassignment was part of a "team restructuring." However, PW-2 (Audit Team Member) testified that no other members of the audit team were reassigned or affected by any restructuring.
*   **External Contradiction (Material):** The Respondent characterizes the move as an "administrative reallocation," while the Complainant and the timing suggest a punitive demotion in response to the audit findings.

**4. Resolution of Contradictions**

*   The "team restructuring" claim is resolved in favor of the Complainant. For a "restructuring" to be a credible explanation, it would typically involve more than one individual or a change in departmental flow. PW-2’s testimony confirms that the change was isolated to Devika Nair.
*   The temporal proximity (one week) between the report of irregularities and the reassignment to lower-level clerical work contradicts the likelihood of a coincidental administrative shift. 

**5. Credibility Findings**

*   **PW-2 (Audit Team Member):** High credibility. As a third-party observer within the same department, their testimony regarding the lack of other reassignments provides an objective baseline that contradicts the Respondent’s narrative.
*   **DW-1 (Sameer Kulkarni):** Low credibility regarding the motive for reassignment. The admission that the action took place within one week of the report, coupled with the failure to provide evidence of a broader restructuring plan, indicates the "restructuring" defense is an after-the-fact rationalization.
*   **Devika Nair:** High credibility. Her account is supported by the direct sequence of documentary evidence (Exhibit G-1 followed immediately by Exhibit G-2).

**6. Power & Vulnerability Findings**

*   **Authority:** Sameer Kulkarni held significant institutional power over Devika Nair, including the ability to unilaterally change her job description and duties.
*   **Vulnerability:** Devika Nair was in a position of professional dependency. Her role as an auditor required her to report on the department managed by her superior, creating a high-risk environment for retaliation.
*   **Dominance:** The act of moving a specialized professional (Auditor) to a non-specialized role (Clerical) is an exercise of dominance that effectively neutralized her ability to continue investigating irregular expenses.

**7. Findings of Fact (FINAL)**

*   Devika Nair performed her duty by reporting irregular financial expenses to management.
*   Sameer Kulkarni, acting in his capacity as Director, removed Devika Nair from her professional role as an auditor within seven days of that report.
*   The reassignment was not part of a broader departmental restructuring, as no other employees were affected.
*   The reassignment from audit duties to clerical work represents a significant reduction in professional responsibility and status.
*   The timing and the singular nature of the reassignment establish that the action was a direct response to the audit report filed by Devika Nair.

**Findings of Fact (FINAL)**