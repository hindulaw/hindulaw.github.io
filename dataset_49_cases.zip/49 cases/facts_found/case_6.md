### **1. Admitted Facts**

*   Fines were issued to a specific subset of shops, rather than all shops in the area.
*   Violations of regulations were present in the shops that were fined.
*   Violations were common and existed across all shops, including those not fined (admitted by PW-1).
*   Enforcement action was selective (admitted by DW-1).
*   Photographic evidence (Exhibit C-1) exists documenting the inspections.

### **2. Disputed Facts**

*   The criteria used to select which specific shops were fined.
*   The justification for the selection (Association claims arbitrary targeting; Officer claims resource constraints).

### **3. Contradictions Identified**

*   **External Contradiction:** The Association identifies the selective action as "arbitrary targeting," whereas the Officer identifies the same action as a result of "limited resources." (Material).

### **4. Resolution of Contradictions**

*   The contradiction regarding the *intent* of the selection is resolved by the material evidence: The Officer admits to selective enforcement. While "limited resources" is provided as a reason for not fining everyone, no evidence or testimony was provided to show a neutral or objective method (such as a lottery, chronological order, or severity scale) for choosing the shops that *were* fined. Therefore, the fact remains that the selection process lacked a documented objective standard.

### **5. Credibility Findings**

*   **PW-1 (Association President):** High credibility. The witness admitted that violations ("minor") existed among the members, which is a statement against interest. 
*   **DW-1 (Officer):** Moderate credibility regarding the act (admitting selectivity), but the justification of "limited resources" is a subjective administrative explanation that does not account for the specific choice of targets.

### **6. Power & Vulnerability Findings**

*   **Authority:** The Enforcement Officer holds the sole power of state-sanctioned inspection and the imposition of financial penalties.
*   **Dependency/Vulnerability:** The Shop Owners are in a position of dependency, as their livelihood is subject to the Officer’s discretionary enforcement.
*   **Risk:** The selective nature of the enforcement creates a condition where the Officer has the power to financially impact specific individuals while exempting others for the same behavior.

### **7. Findings of Fact (FINAL)**

*   Violations were prevalent across the entire shop population.
*   The Enforcement Officer was aware that violations were common to all shops.
*   The Enforcement Officer chose to penalize only a specific group of shop owners.
*   The Enforcement Officer did not provide an objective or systematic criteria for how the specific shops were selected for fining versus those that were bypassed.
*   The enforcement of rules was inconsistent and non-uniform despite the uniformity of the violations.

**Findings of Fact (FINAL)**