### 1. Admitted Facts
* Ananya Mehta (Parent A) and Kunal Mehta (Parent B) are the biological parents of a 6-year-old child and are currently separated.
* The child is currently enrolled in school.
* Ananya Mehta currently manages the child's primary routine and schooling.
* Kunal Mehta maintains a bond with the child.
* Ananya Mehta has restricted Kunal Mehta’s access to the child during the mid-week period.

### 2. Disputed Facts
* Whether the child’s best interests are served by a sole custody arrangement focused on routine or a shared custody arrangement focused on parental bonding.
* The specific cause of the child’s anxiety.
* Whether the current "stability" cited by Ananya Mehta is functioning as actual stability or as a source of stress for the child.

### 3. Contradictions Identified
* **External Contradiction (Material):** Ananya Mehta asserts that the current routine provides "stability," yet the Teacher (PW-2) observes that the child exhibits "anxiety" specifically following transitions.
* **Internal Contradiction (Material):** Ananya Mehta argues for the child's welfare through "routine" while admitting to limiting mid-week access, which creates a binary separation between the parents rather than a consistent shared environment.

### 4. Resolution of Contradictions
* The Teacher's observation of anxiety is a neutral, third-party factual assessment of the child's state. It outweighs Ananya's subjective claim of "stability."
* The resolution indicates that while the child's academic performance is steady, the *process* of moving between the two parents under the current restricted access model is causing emotional distress. 
* Ananya's admission of limiting access confirms that the current schedule is not a collaborative effort but a managed one, contributing to the "transition" stress identified by the teacher.

### 5. Credibility Findings
* **Teacher (PW-2):** High credibility. As a professional educator with no personal stake in the custody outcome, their observation of the child’s anxiety is the most objective piece of evidence regarding the child's well-being.
* **Ananya Mehta (PW-1):** Moderate credibility. While her commitment to schooling is documented by records (Exhibit F-1), her admission of limiting access suggests a motivation to maintain unilateral control over the child's schedule.
* **Kunal Mehta (PW-3):** Moderate credibility. His claim of a "strong bond" is consistent with his pursuit of shared custody, though it is a subjective assessment of his own relationship.

### 6. Power & Vulnerability Findings
* **The Child:** The 6-year-old child is the most vulnerable party, possessing no autonomy over the schedule and suffering the physical/emotional manifestation of the parents' conflict (anxiety).
* **Ananya Mehta:** Currently holds the position of authority regarding the child’s daily life, school interaction, and the gatekeeping of paternal access.
* **Kunal Mehta:** Occupies a position of dependency regarding the schedule, relying on either Ananya’s consent or a change in the arrangement to maintain his bond with the child.

### 7. Findings of Fact (FINAL)
* The child is 6 years old and performs well in a school setting.
* There is a consistent pattern of anxiety displayed by the child immediately following transitions between the parents.
* Ananya Mehta has intentionally limited Kunal Mehta’s involvement during the school week to maintain a specific routine.
* Kunal Mehta is an active parent seeking increased involvement.
* The current custody arrangement, characterized by limited mid-week access and rigid transitions, correlates with the child’s observed emotional anxiety.

**Findings of Fact (FINAL)**