### 1. Admitted Facts
*   A verbal dispute occurred between Rohit Malhotra and Dev Arjun in a street setting.
*   Physical contact occurred between Dev Arjun and Rohit Malhotra.
*   Dev Arjun used physical force (a push) against Rohit Malhotra.
*   Rohit Malhotra sustained a minor injury as a result of the encounter, as documented in Exhibit P-1.

### 2. Disputed Facts
*   Whether Rohit Malhotra advanced aggressively toward Dev Arjun prior to the physical contact.
*   Whether the physical contact is characterized as a "strike" (as alleged by Rohit) or a "push" (as claimed by Dev).
*   The sequence of events identifying who initiated the physical escalation.

### 3. Contradictions Identified
*   **External Contradiction (Material):** Rohit claims he was "struck," whereas Dev claims he "pushed" Rohit. This goes to the nature of the force used.
*   **External Contradiction (Material):** Rohit implies he was the victim of a strike during a dispute; Dev claims Rohit was the initial aggressor who "advanced aggressively."
*   **Neutral Contradiction (Material):** The bystander (PW-2) was unable to confirm who initiated the contact, contradicting both parties’ definitive versions of the start of the physical altercation.

### 4. Resolution of Contradictions
*   **Nature of Force:** Dev’s admission during cross-examination that he pushed "with force," combined with the "minor injury report" (Exhibit P-1), establishes that the contact was of sufficient velocity and impact to cause physical harm. The distinction between a "strike" and a "forceful push" is resolved as a high-impact physical intervention by Dev.
*   **Initiation of Aggression:** Because the independent witness (PW-2) could not determine who initiated contact and both parties provide self-serving accounts of the initiation, the fact of a "street dispute" confirms mutual verbal engagement, but the specific physical initiator remains unverified by third-party evidence.

### 5. Credibility Findings
*   **Dev Arjun (DW-1):** Demonstrates moderate to high credibility regarding the physical act, as he admitted to using "force," which is an admission against his own interest.
*   **Rohit Malhotra (PW-1):** Credibility regarding the result of the encounter is supported by the physical evidence of the injury report (Exhibit P-1).
*   **Bystander (PW-2):** High credibility due to a lack of incentive to lie, though his testimony is limited by his failure to observe the moment of initiation.

### 6. Power & Vulnerability Findings
*   The record indicates a peer-to-peer interaction in a public space.
*   There is no evidence of a pre-existing power imbalance, institutional authority, or dependency between Rohit and Dev.
*   Both parties were active participants in a "street dispute," suggesting a temporary environment of mutual confrontation rather than a dynamic of dominance and submission.

### 7. Findings of Fact (FINAL)
1.  A verbal confrontation occurred between Rohit Malhotra and Dev Arjun in public.
2.  During the course of this dispute, Rohit Malhotra moved toward Dev Arjun.
3.  Dev Arjun responded by pushing Rohit Malhotra with significant physical force.
4.  The force of this push was sufficient to cause a minor injury to Rohit Malhotra.
5.  The evidence confirms that the physical injury was a direct result of Dev Arjun’s forceful push, following a period of mutual verbal hostility.