### **1. Admitted Facts**

*   A verbal argument occurred between Arjun Das and Karan Singh.
*   Arjun Das was shouting during the course of the argument.
*   Physical contact occurred between Karan Singh and Arjun Das during the exchange.
*   Arjun Das fell to the ground following the physical contact.
*   Arjun Das sustained physical injuries as a result of the fall, documented in Exhibit C-1.

---

### **2. Disputed Facts**

*   The intent behind the physical contact: Whether the contact was a deliberate "push" (as claimed by Arjun Das) or "accidental contact" (as claimed by Karan Singh).

---

### **3. Contradictions Identified**

*   **External Contradiction:** Arjun Das testifies he was pushed. Karan Singh testifies the contact was accidental.
*   **Classification:** Material. The nature of the physical act is central to determining the cause of the fall and subsequent injury.

---

### **4. Resolution of Contradictions**

*   The contradiction regarding the nature of the contact is resolved by the context of the admitted behavior. Both parties admit to a heated argument involving shouting. 
*   Physical contact occurring in the immediate context of admitted verbal aggression is more consistent with a proactive physical gesture than an unrelated accident. 
*   Karan Singh’s admission of "contact" corroborates the physical nexus, while the resulting fall and documented injuries (Exhibit C-1) corroborate the force described by Arjun Das.

---

### **5. Credibility Findings**

*   **Arjun Das:** Credible. His testimony is consistent with the physical evidence of injury and the admitted atmosphere of the argument. His admission that he was also shouting increases his credibility as he did not attempt to portray himself as a silent or passive participant.
*   **Karan Singh:** Partially credible. He admits to the contact but characterizes it as accidental. This characterization is less consistent with the admitted environment of a shouting match.

---

### **6. Power & Vulnerability Findings**

*   **Authority/Dependency:** There is no evidence of a pre-existing power imbalance or dependency between the parties.
*   **Situational Vulnerability:** At the moment of the shouting match and physical contact, Arjun Das became vulnerable to physical force, resulting in a fall that he was unable to prevent.

---

### **7. Findings of Fact (FINAL)**

1.  Arjun Das and Karan Singh were engaged in a mutual, heated verbal altercation involving shouting.
2.  During the height of this aggression, Karan Singh initiated physical contact with Arjun Das.
3.  This contact was forceful enough to cause Arjun Das to lose his balance and fall.
4.  The fall caused physical injuries to Arjun Das, as evidenced by the photographs in Exhibit C-1.
5.  The physical contact was not a random accident but occurred as a direct component of the admitted argument.

**Findings of Fact (FINAL)**