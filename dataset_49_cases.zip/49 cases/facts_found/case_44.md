### 1. Admitted Facts
*   A specific subset of applicants from the Transport Permit Applicants Group was granted permits, while others were not.
*   The Respondent (Permit Allocation Officer) was the sole authority responsible for the selection process.
*   There is no written scoring system, objective evaluation rubric, or contemporaneous evaluation notes documenting the selection process.
*   The selection was based on the Respondent’s personal assessment of "experience."
*   Exhibit G-1 (Permit list) and Exhibit G-2 (Applicant profiles) constitute the material record of the outcome and the pool of candidates.

### 2. Disputed Facts
*   Whether the selected applicants actually possessed higher levels of "experience" compared to those who were rejected.
*   Whether the selection was based on merit/expertise or on personal favoritism.
*   The specific criteria used to define "experience" in the absence of written guidelines.

### 3. Contradictions Identified
*   **External Contradiction (Material):** The Respondent claims an "expertise-based" selection process, yet the material record (Exhibits G-1 and G-2) lacks any data, rankings, or notes that demonstrate how "expertise" was measured or why one applicant's profile was superior to another.
*   **Internal Contradiction (DW-1):** The Respondent asserts a structured professional judgment was exercised but admits under cross-examination that no scoring system or written justifications exist to support those judgments.

### 4. Resolution of Contradictions
*   The claim of an "expertise-based" selection is unverifiable. When an official claims to use a specific metric (experience) but fails to record or define that metric, the "judgment" is functionally indistinguishable from arbitrary choice. 
*   The contradiction between the claim of "judgment" and the absence of "notes" is resolved in favor of the Complainants’ assertion of non-transparency. Without a recorded process, the assertion of expertise remains an unsubstantiated opinion of the Respondent rather than a demonstrable fact of the process.

### 5. Credibility Findings
*   **PW-1 (Complainant Representative):** High credibility. Their claim that the process lacked transparency is corroborated by the Respondent’s own admission regarding the lack of a scoring system.
*   **DW-1 (Permit Officer):** Low credibility regarding the objectivity of the process. While the Officer may believe they used "experience," the failure to document any criteria or maintain notes suggests a reliance on subjective preference rather than a consistent, repeatable standard. Natural human behavior suggests that without a written system, personal bias is likely to influence outcomes.

### 6. Power & Vulnerability Findings
*   **Authority:** The Respondent held total discretionary power over the allocation of permits, which directly impacts the economic survival of the applicants.
*   **Dependency:** The Applicants Group was in a position of complete dependency on the Respondent’s decision.
*   **Vulnerability:** The lack of a written scoring system created a high-vulnerability environment for applicants. They had no way to ensure fair treatment or to understand the basis of their rejection, leaving them at the mercy of the Officer’s undocumented whims.

### 7. Findings of Fact (FINAL)
1.  The permit allocation process was conducted without any objective, written, or transparent criteria.
2.  The Respondent selected permit recipients based on subjective "judgment" that was not recorded or quantified at the time of the decision.
3.  There is no evidence in the record (Exhibit G-1 and G-2) to demonstrate a consistent application of "experience" as a qualifying factor.
4.  The absence of an evaluation framework prevented any applicant from knowing the requirements for success or the reasons for failure.
5.  The process was entirely discretionary and lacked any safeguards against favoritism or personal bias.

Findings of Fact (FINAL)