### **1. Admitted Facts**

*   Rhea Kapoor and Saurabh Kapoor are the parents of the child in question.
*   A visitation or contact schedule exists between Parent B (Saurabh) and the child.
*   Communication regarding the scheduling of visits has occurred via messages (Exhibit F-1).
*   The child has undergone sessions with a counselor (PW-2).
*   Difficulties in executing the visitation schedule have occurred.

---

### **2. Disputed Facts**

*   Whether Rhea Kapoor actively discourages the child from maintaining contact with Saurabh.
*   Whether Rhea Kapoor speaks negatively about Saurabh in the presence of the child.
*   Whether the scheduling issues are "practical constraints" or "intentional obstructions."
*   Whether the child’s "mixed feelings" are a result of parental coaching or the natural result of the family's transition/environment.

---

### **3. Contradictions Identified**

*   **External Contradiction:** Saurabh alleges a "pattern of obstruction" and coaching; however, the Counselor (PW-2) specifically noted that "no clear coaching" was found. (Material)
*   **External Contradiction:** Saurabh characterizes scheduling delays as purposeful interference; Rhea characterizes them as logistical/practical issues. (Material)

---

### **4. Resolution of Contradictions**

*   The contradiction regarding "coaching" is resolved in favor of the Counselor’s findings. As a neutral professional trained to detect influence, the Counselor’s observation of "no clear coaching" outweighs Saurabh’s subjective allegation.
*   The contradiction regarding "obstruction vs. practical constraints" is partially resolved by the existence of Exhibit F-1. The messages show that scheduling attempts are being made, which supports the existence of a process, even if flawed. Without specific evidence of bad-faith cancellations in the record, the claim of "intentional obstruction" remains unproven.

---

### **5. Credibility Findings**

*   **PW-2 (Counselor):** High credibility. As a neutral third party with no personal stake in the custody or visitation outcome, their assessment of the child’s state and the absence of coaching is the most reliable evidence.
*   **PW-1 (Saurabh) & DW-1 (Rhea):** Both parties possess a high incentive to frame the facts to suit their respective positions (securing more access vs. defending against allegations of misconduct). Their testimonies regarding intent are treated as subjective.
*   **Exhibit F-1 (Messages):** High credibility as contemporaneous records of interaction, though they prove only that scheduling occurred, not the emotional tone or underlying intent.

---

### **6. Power & Vulnerability Findings**

*   **Rhea Kapoor (Parent A):** Holds logistical authority and primary control over the child's daily environment, creating a position of power regarding the facilitation of visits.
*   **Saurabh Kapoor (Parent B):** Dependent on Parent A’s cooperation for contact, placing him in a position of vulnerability regarding his relationship with the child.
*   **The Child:** The most vulnerable party, experiencing "mixed feelings" amidst parental friction. There is no evidence that the child is acting out of fear of either parent, but rather reacting to the conflict.

---

### **7. Findings of Fact (FINAL)**

1.  The visitation schedule is experiencing frequent logistical friction, as evidenced by the necessity of ongoing scheduling messages.
2.  The child expresses "mixed feelings" regarding the situation, but these feelings have not been linked to "coaching" or psychological manipulation by Rhea Kapoor according to professional assessment.
3.  There is no material evidence on the record—beyond the allegations of Saurabh—that Rhea Kapoor speaks negatively about him to the child.
4.  The record confirms a breakdown in logistical cooperation but does not support the existence of a deliberate campaign of parental alienation.
5.  The child’s emotional state is neutral-to-mixed, without evidence of fear-based suppression or forced alignment with one parent.

**Findings of Fact (FINAL)**