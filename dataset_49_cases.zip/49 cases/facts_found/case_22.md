### 1. Admitted Facts
*   A verbal argument occurred between Kavya Rao and Mohan Rao.
*   The argument was mutual in nature.
*   Both parties raised their voices, which was audible to a third party (Neighbor).
*   Physical contact occurred between Mohan Rao and Kavya Rao’s arm.
*   Kavya Rao sustained a bruise on her arm as a result of the incident (Exhibit P-1).
*   Text messages were exchanged between the parties on the night of the incident (Exhibit P-2).
*   Mohan Rao briefly blocked the doorway during the encounter.

### 2. Disputed Facts
*   Whether the physical contact was an intentional "grab and push" (as alleged by Kavya Rao).
*   Whether the physical contact was "accidental" while attempting to leave the room (as alleged by Mohan Rao).

### 3. Contradictions Identified
*   **Internal Contradiction (Mohan Rao):** Mohan Rao claims he was "trying to leave the room" (an act of withdrawal), yet admits to "blocking the doorway" (an act of physical obstruction and confrontation).
*   **External Contradiction:** Kavya Rao describes the force as a specific grab and push; Mohan Rao describes it as incidental contact.

### 4. Resolution of Contradictions
*   The contradiction in Mohan Rao’s testimony is **material**. One cannot simultaneously be attempting to exit a room while intentionally blocking the only exit. The admission of blocking the doorway indicates an active effort to control the space and the other person's movement, which is inconsistent with a narrative of passive accidental contact.
*   The presence of a bruise (Exhibit P-1) requires a specific degree of localized force. Such an injury is more consistent with a grab or a forceful push than with an incidental brush while passing through a doorway, particularly when the person claiming accident admits to blocking that doorway.

### 5. Credibility Findings
*   **Kavya Rao (PW-1):** Credibility is high. She admitted the argument was mutual, showing a lack of intent to sanitize her own behavior. Her description of the injury is supported by physical evidence (P-1).
*   **Mohan Rao (DW-1):** Credibility is low regarding the nature of the contact. His claim of "accidental" contact is undermined by his admission that he blocked the doorway, suggesting a state of physical aggression or control rather than an attempt to de-escalate or leave.
*   **Neighbor (PW-2):** Credibility is high; provides neutral confirmation of the high-tension environment (shouting).

### 6. Power & Vulnerability Findings
*   **Authority/Dominance:** Mohan Rao exercised physical dominance by blocking the doorway, thereby restricting Kavya Rao’s freedom of movement within the domestic space.
*   **Vulnerability:** Kavya Rao was in a position of physical vulnerability when her path was blocked and during the subsequent physical contact that resulted in a bruise.

### 7. Findings of Fact (FINAL)
*   A high-intensity verbal argument took place between Kavya Rao and Mohan Rao.
*   During this argument, Mohan Rao used his body to block the doorway, preventing Kavya Rao from moving freely.
*   While blocking the doorway and engaging in the argument, Mohan Rao applied forceful physical contact to Kavya Rao’s arm.
*   This physical contact was not an accident; it was an assertive physical act that resulted in a visible bruise on Kavya Rao’s arm.
*   The contact occurred within a context where Mohan Rao was actively restricting Kavya Rao’s movement.