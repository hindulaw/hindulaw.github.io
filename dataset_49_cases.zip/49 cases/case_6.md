# **⚖️ CASE 6 — AUTHORITY / GOVERNANCE ABUSE**

## ***Selective Enforcement***

### **Parties**

* **Shop Owners Association vs Enforcement Officer**

---

## **PW-1: Association President**

### **Examination-in-Chief**

**Q:** What is alleged?  
**A:** Only some shops fined.

📎 Inspection photos **Exhibit C-1**

---

### **Cross-Examination**

**Q:** Violations existed?  
**A:** Minor, common to all.

---

## **DW-1: Officer**

### **Examination-in-Chief**

**Q:** Why selective action?  
**A:** Limited resources.

---

## **Final Arguments**

* **Complainant:** Arbitrary targeting.  
* **Respondent:** Administrative discretion.