# ⚖️ CASE 48 — MIXED / EDGE CASE

## *Mental Health Affecting Consent*

### Parties

* **Complainant:** Ayesha Rahman
* **Respondent:** Farhan Ali

### Facts

Ayesha entered a financial guarantee while undergoing severe anxiety. She later alleges inability to assess risk. Farhan claims no knowledge of condition.

### Evidence

* Guarantee document (Exhibit E-1)
* Therapy appointment confirmations (Exhibit E-2)

### Witnesses

* **PW-1:** Ayesha
* **PW-2:** Therapist (limited factual testimony)
* **DW-1:** Farhan

### Trial Highlights

* **PW-2:** Confirms anxiety episodes; no opinion on capacity.
* **Cross of Farhan:** Admits awareness of distress.

### Final Arguments

* **Complainant:** Capacity impaired.
* **Respondent:** No proof of incapacity at signing.
