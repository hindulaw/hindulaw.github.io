
# **⚖️ CASE 11 — CRIMINAL (NON-VIOLENT)**

## ***Advance Taken, Partial Delivery***

### **Parties**

* **Complainant:** Neeraj Khanna  
* **Accused:** Mohit Agarwal

### **Facts**

Neeraj paid advance for goods. Partial delivery made; balance unpaid.

### **Evidence**

* Payment receipts  
* Partial delivery photos

### **Trial Focus**

Intent at inception vs later failure.

### **Final Arguments**

* **Prosecution:** Partial delivery camouflage  
* **Defence:** Genuine attempt, later failure
