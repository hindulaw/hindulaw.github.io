# **⚖️ CASE 13 — CRIMINAL (NON-VIOLENT)**

## ***Misuse of Entrusted Funds***

### **Parties**

* **Complainant:** Housing Cooperative  
* **Accused:** Treasurer Rohan Mehta

### **Facts**

Funds withdrawn for “repairs”; repairs incomplete.

### **Evidence**

* Bank withdrawals  
* Contractor statements

### **Trial Issue**

Temporary diversion vs misappropriation.

### **Final Arguments**

* **Prosecution:** Personal use inferred  
* **Defence:** Delay, not misuse
