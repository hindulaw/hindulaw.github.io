# ⚖️ CASE 40 — AUTHORITY / GOVERNANCE ABUSE

## *Selective Penalty*

### Parties

* **Complainant:** Market Vendors Collective
* **Respondent:** Enforcement Supervisor

### Facts

Collective alleges penalties imposed only on certain vendors for identical violations. Supervisor claims phased enforcement.

### Evidence

* Penalty notices (Exhibit G-1)
* Photos of non-penalized vendors (Exhibit G-2)

### Witnesses

* **PW-1:** Collective Representative
* **DW-1:** Enforcement Supervisor

### Trial Highlights

* **Cross of DW-1:** No written criteria for selection.

### Final Arguments

* **Complainant:** Arbitrary targeting.
* **Respondent:** Operational sequencing.
