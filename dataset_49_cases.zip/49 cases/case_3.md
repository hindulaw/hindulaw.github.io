# **⚖️ CASE 3 — CRIMINAL (VIOLENT / THREAT)**

## ***Simple Assault***

### **Parties**

* **Victim:** Arjun Das  
* **Accused:** Karan Singh

---

## **PW-1: Arjun Das**

### **Examination-in-Chief**

**Q:** What happened?  
**A:** He pushed me during an argument; I fell.

📎 Injury photos **Exhibit C-1**

---

### **Cross-Examination**

**Q:** You were shouting too?  
**A:** Yes.

---

## **DW-1: Karan Singh**

### **Examination-in-Chief**

**Q:** Did you push him?  
**A:** No, accidental contact.

---

## **Final Arguments**

* **Prosecution:** Intent inferred from aggression.  
* **Defence:** Accident during heated exchange.