# ⚖️ CASE 21 — CRIMINAL (VIOLENT / THREAT)

## *Threat Without Weapon*

### Parties

* **Victim:** Leena Thomas
* **Accused:** Prakash Menon

### Facts

During a property dispute, Prakash allegedly said words implying harm.

### Evidence

* Neighbor testimony (Exhibit P-1)

### Witnesses

* PW-1 Leena
* PW-2 Neighbor
* DW-1 Prakash

### Trial Highlights

* **Cross of PW-2:** Heard raised voice, exact words unclear.

### Final Arguments

* **Prosecution:** Threat assessed by fear caused.
* **Defence:** Heated words, no real threat.
