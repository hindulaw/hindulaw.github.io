# ⚖️ CASE 28 — FAMILY & PERSONAL RELATIONS

## *Mental Cruelty Between Spouses*

### Parties

* **Complainant:** Priti Joshi
* **Respondent:** Akash Joshi

### Facts

Priti alleges persistent belittling, control over finances, and isolation. Akash denies cruelty and claims mutual arguments.

### Evidence

* Message logs (Exhibit F-1)
* Shared expense statements (Exhibit F-2)

### Witnesses

* **PW-1:** Priti
* **PW-2:** Friend
* **DW-1:** Akash

### Trial Highlights

* **PW-2:** Observed emotional distress.
* **Cross of Priti:** No contemporaneous complaint.
* **Cross of Akash:** Admits monitoring expenses.

### Final Arguments

* **Priti:** Pattern constitutes cruelty.
* **Akash:** Marital disagreements, not abuse.
