# ⚖️ CASE 20 — CRIMINAL (VIOLENT / THREAT)

## *Group Altercation*

### Parties

* **Victim:** Sameer Qureshi
* **Accused:** Three Individuals (Group)

### Facts

Street argument escalated; Sameer claims he was surrounded and struck.

### Evidence

* Minor injury photos (Exhibit P-1)
* Conflicting witness statements

### Witnesses

* PW-1 Sameer
* PW-2 Bystander
* DW-1 Group Member

### Trial Highlights

* **PW-2:** Chaos; unclear who struck.
* **Cross:** No clear aggressor.

### Final Arguments

* **Prosecution:** Collective intimidation inferred.
* **Defence:** Mutual scuffle; no proof of assault.
