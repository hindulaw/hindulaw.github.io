# **⚖️ CASE 1 — CIVIL / SERVICE & EMPLOYMENT**

## ***Excessive Supervision & Mental Harassment***

### **Parties**

* **Complainant:** Nikhil Varma  
* **Respondent:** Anita Rao

---

## **Witness PW-1: Nikhil Varma**

### **Examination-in-Chief**

**Q:** What changed after the respondent became manager?  
**A:** Daily monitoring, public criticism, late-night messages demanding explanations.

**Q:** How did this affect you?  
**A:** Anxiety, sleep problems, fear of speaking in meetings.

📎 Emails marked **Exhibit C-1**

---

### **Cross-Examination**

**Q:** You missed deadlines, correct?  
**A:** Occasionally.

**Q:** No written complaint filed earlier?  
**A:** I feared retaliation.

---

## **Witness DW-1: Anita Rao**

### **Examination-in-Chief**

**Q:** Why did you monitor closely?  
**A:** Performance concerns across the team.

---

### **Cross-Examination**

**Q:** You criticized him in team meetings?  
**A:** I gave feedback.

**Q:** Any written warnings before emails?  
**A:** No.

---

## **Final Arguments**

* **Complainant:** Supervision became intimidation; no prior warnings.  
* **Respondent:** Legitimate managerial control; sensitivity exaggerated.