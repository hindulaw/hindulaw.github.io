# ⚖️ CASE 16 — CRIMINAL (NON-VIOLENT)

## *Digital Payment Fraud (Small Amount)*

### Parties

* **Complainant:** Pooja Nair
* **Accused:** Kunal Arora

### Facts

Pooja paid online for services; service not delivered. Kunal claims account compromise and refund attempt.

### Evidence

* Payment receipt (Exhibit P-1)
* Chat logs (Exhibit P-2)

### Witnesses

* PW-1 Pooja
* PW-2 Platform support agent
* DW-1 Kunal

### Trial Highlights

* **PW-2:** Account flagged later; timing disputed.
* **Cross of DW-1:** No refund proof.

### Final Arguments

* **Prosecution:** Control of account implies responsibility.
* **Defence:** Third-party misuse; no intent.
