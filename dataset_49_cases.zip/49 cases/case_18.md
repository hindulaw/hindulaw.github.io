# ⚖️ CASE 18 — CRIMINAL (NON-VIOLENT)

## *False Complaint Allegation*

### Parties

* **Complainant:** Nisha Roy
* **Accused:** (Counter-complainant) Ajay Sen

### Facts

Nisha alleges intimidation; Ajay alleges complaint was false to settle a dispute.

### Evidence

* Initial complaint text (Exhibit P-1)
* Prior dispute messages (Exhibit D-1)

### Witnesses

* PW-1 Nisha
* DW-1 Ajay

### Trial Highlights

* **Cross of PW-1:** Timeline inconsistencies.
* **Cross of DW-1:** Prior heated exchanges admitted.

### Final Arguments

* **Prosecution:** Fear reported contemporaneously.
* **Defence:** Motive to harass shown.
