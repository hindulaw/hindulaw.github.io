# ⚖️ CASE 43 — AUTHORITY / GOVERNANCE ABUSE

## *Whistleblower Retaliation*

### Parties

* **Complainant:** Internal Auditor — Devika Nair
* **Respondent:** Department Director — Sameer Kulkarni

### Facts

Devika reported irregular expense approvals to senior management. Afterward, she was removed from audit duties and reassigned to clerical work. Sameer claims reassignment was due to “team restructuring.”

### Evidence

* Internal audit email (Exhibit G-1)
* Reassignment memo (Exhibit G-2)

### Witnesses

* **PW-1:** Devika Nair
* **PW-2:** Audit Team Member
* **DW-1:** Sameer Kulkarni

### Trial Highlights

* **PW-2:** Confirms no other auditor was reassigned.
* **Cross of DW-1:** Admits reassignment occurred within one week of report.

### Final Arguments

* **Complainant:** Temporal proximity shows retaliation.
* **Respondent:** Administrative reallocation, not punishment.