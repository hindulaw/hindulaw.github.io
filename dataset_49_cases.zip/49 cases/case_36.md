# ⚖️ CASE 36 — PROPERTY & CONTRACT

## *Sale Agreement Dispute*

### Parties

* **Plaintiff:** Aarav Constructions
* **Defendant:** Maya Kulkarni

### Facts

Aarav Constructions alleges Maya failed to complete payment under a sale agreement despite possession being offered. Maya alleges construction delays and incomplete amenities.

### Evidence

* Sale agreement (Exhibit P-1)
* Construction progress photos (Exhibit D-1)

### Witnesses

* **PW-1:** Project Manager (Aarav)
* **DW-1:** Maya Kulkarni

### Trial Highlights

* **Cross of PW-1:** Admits delay in clubhouse completion.
* **Cross of DW-1:** Admits occupying the premises intermittently.

### Final Arguments

* **Plaintiff:** Payment obligation independent of minor delays.
* **Defendant:** Payment linked to promised completion.
