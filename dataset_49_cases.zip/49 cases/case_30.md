
# ⚖️ CASE 30 — FAMILY & PERSONAL RELATIONS

## *Sibling Responsibility Dispute*

### Parties

* **Complainant:** Alisha Verma
* **Respondent:** Rohit Verma

### Facts

Alisha claims Rohit avoids shared financial responsibility for a dependent parent. Rohit claims unequal income capacity.

### Evidence

* Expense records (Exhibit F-1)
* Income summaries (Exhibit F-2)

### Witnesses

* **PW-1:** Alisha
* **DW-1:** Rohit

### Trial Highlights

* **Cross of Rohit:** Acknowledges discretionary spending.
* **Cross of Alisha:** Admits no formal cost-sharing agreement.

### Final Arguments

* **Alisha:** Fair contribution expected.
* **Rohit:** Contributions must reflect capacity.
