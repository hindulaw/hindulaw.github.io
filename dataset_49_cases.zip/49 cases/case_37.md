# ⚖️ CASE 37 — PROPERTY & CONTRACT

## *Inheritance Contest*

### Parties

* **Plaintiff:** Rahul Sharma
* **Defendant:** Neha Sharma

### Facts

Rahul alleges unequal distribution of inherited property based on a late-disclosed family arrangement. Neha claims arrangement reflected prior caregiving.

### Evidence

* Family arrangement document (Exhibit P-1)
* Caregiving expense records (Exhibit D-1)

### Witnesses

* **PW-1:** Rahul
* **PW-2:** Family elder
* **DW-1:** Neha

### Trial Highlights

* **Elder:** Arrangement discussed informally, not finalized.
* **Cross of Neha:** No written consent from Rahul.

### Final Arguments

* **Plaintiff:** Arrangement lacks mutual consent.
* **Defendant:** Equitable distribution based on contribution.
