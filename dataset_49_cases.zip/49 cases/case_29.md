# ⚖️ CASE 29 — FAMILY & PERSONAL RELATIONS

## *Elder Neglect Allegation*

### Parties

* **Complainant:** Kamala Menon (daughter)
* **Respondent:** Rajiv Menon (son)

### Facts

Kamala alleges Rajiv failed to provide adequate care to their elderly mother, leading to missed medical appointments. Rajiv claims Kamala obstructed coordination.

### Evidence

* Appointment logs (Exhibit F-1)
* Care messages between siblings (Exhibit F-2)

### Witnesses

* **PW-1:** Kamala
* **PW-2:** Home nurse
* **DW-1:** Rajiv

### Trial Highlights

* **Nurse:** Care inconsistent due to scheduling disputes.
* **Cross of Kamala:** Admits not sharing updated schedules.
* **Cross of Rajiv:** Admits travel reduced availability.

### Final Arguments

* **Complainant:** Pattern of neglect.
* **Respondent:** Coordination failures, not neglect.
