# ⚖️ CASE 47 — MIXED / EDGE CASE

## *Both Parties Lying*

### Parties

* **Complainant:** Freelance Designer — Tara Singh
* **Respondent:** Client — Rohan Gupta

### Facts

Tara alleges non-payment; Rohan alleges incomplete work. Messages show both overstated claims.

### Evidence

* Invoices (Exhibit E-1)
* Project messages (Exhibit E-2)

### Witnesses

* **PW-1:** Tara
* **DW-1:** Rohan

### Trial Highlights

* **Cross of PW-1:** Admits missed deadline.
* **Cross of DW-1:** Admits partial payment withheld despite usable work.

### Final Arguments

* **Complainant:** Substantial performance merits payment.
* **Respondent:** Non-completion justifies withholding.
