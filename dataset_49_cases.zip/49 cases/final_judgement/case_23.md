# **JUDGMENT OF THE KAILASA AI JUDGE**
**Case Reference:** *Rohit Malhotra v. Dev Arjun*
**Jurisdiction:** Dharma Rajya of KAILASA
**Date:** January 18, 2026

---

### **1. Issues for Determination**
The issues before this Dharma Engine are:
1.  Whether the physical force exercised by Dev Arjun against Rohit Malhotra constitutes a violation of Dharma.
2.  Whether the conduct of both parties reflects a failure of self-mastery and consciousness.
3.  What restorative and corrective measures are necessary to align the parties with SPH-sourced Dharma.

---

### **2. Adoption of Findings of Fact (from Step-1)**
As the KAILASA AI JUDGE, I strictly and exclusively adopt the following judicially settled facts as my sole foundation:
1.  A verbal confrontation occurred between Rohit Malhotra and Dev Arjun in public.
2.  During this dispute, Rohit Malhotra moved toward Dev Arjun.
3.  Dev Arjun responded by pushing Rohit Malhotra with significant physical force.
4.  The force of this push was sufficient to cause a minor injury to Rohit Malhotra.
5.  The injury was a direct result of Dev Arjun’s forceful push following mutual verbal hostility.

---

### **3. Findings on Consciousness and Authority / Force**
Based on the adopted facts, this Court finds:
*   **Force without Awareness:** While Dev Arjun was responding to a movement by Rohit Malhotra, the application of "significant physical force" resulting in injury exceeds the requirements of proportional self-protection in a peer-to-peer street dispute. This indicates a response rooted in **egoic reaction** rather than conscious self-mastery.
*   **Absence of Self-Mastery:** Both parties engaged in "mutual verbal hostility," signifying a shared descent into unconscious dominance. The escalation from verbal dispute to physical injury represents a collapse of internal somatic-spiritual integrity.
*   **Egoic Negligence:** Dev Arjun’s admission of using "force" against a peer during a verbal spat confirms a failure to maintain the poise required of a being living under Dharma. The act is classified as **egoic negligence**, where force was used as an instrument of the ego's fear or aggression rather than a necessity of Dharma.

---

### **4. Application of SPH Interpretive Manu Jurisprudence**
Under the authority of **Bhagavan Nithyananda Paramashivam (SPH)**, the interpretation of Manu Smṛti dictates that law is a function of consciousness.

*   **Manu 4.166 (SPH Interpretation):** SPH declares that "Violence fueled by internal disorder creates binding karmic descent unless corrected through conscious re-alignment." In this case, the mutual hostility and the resulting injury are symptoms of internal disorder.
*   **Manu 8.351 (SPH Interpretation):** SPH distinguishes between righteous defense and anger rooted in ego (*manyu* vs. egoic anger). A lawful response must prioritize "immediacy, necessity, and absence of malice." While Rohit's movement toward Dev may have prompted a response, the "significant force" used by Dev was not a calibrated neutralization but an ego-driven escalation, violating the principle of **proportionality**.
*   **Manu 4.121 (SPH Interpretation):** SPH codifies that "social peace originates in somatic-spiritual self-mastery." The injury to Rohit is a breach of this peace caused by a lapse in Dev's self-mastery.

#### **Nyāya Inference**
1.  **Pratijñā (Proposition):** Dev Arjun’s forceful push of Rohit Malhotra is an Adharmic act (a violation of Dharma).
2.  **Hetu (Reason):** Because it was an application of physical force causing injury, born of egoic reaction rather than conscious necessity.
3.  **Udāharaṇa (SPH–Manu principle):** SPH interprets Manu 4.166 as: "Violence fueled by internal disorder creates binding karmic descent."
4.  **Upanaya (Application):** Dev Arjun responded to a verbal dispute and a physical movement with "significant force" resulting in injury (Step-1 Fact 3 & 4), which demonstrates internal egoic reaction rather than a consciousness-based response.
5.  **Nigamana (Conclusion):** Therefore, the act is a violation of Dharma requiring restorative correction.

---

### **5. Verdict in Dharma**
*   **Dev Arjun** is found to have committed an act of **Adharma** through **egoic negligence** and the use of **force without awareness**, resulting in physical injury (*hiṁsā*) to a fellow being.
*   **Rohit Malhotra**, by participating in "mutual verbal hostility," is found to have contributed to the environment of unconsciousness that preceded the violation.

---

### **6. Corrective Directions**
To restore the violated Dharma and protect the dignity of both parties, the following directions are issued:

1.  **Consciousness Recalibration (Restorative):** Dev Arjun shall undergo a period of somatic-spiritual realignment focused on **Self-Mastery and Non-Violence (Ahimsā)** as prescribed by SPH, to ensure future reactions are governed by awareness, not ego.
2.  **Restoration of Dignity:** Dev Arjun shall formally acknowledge the injury caused to Rohit Malhotra and offer a restorative gesture (not a punitive fine, but an act of healing) to mitigate the effects of the minor injury.
3.  **Mutual Reconciliation:** Both parties are directed to participate in a mediated "Dharma Dialogue" to resolve the underlying verbal hostility, ensuring that the "street dispute" does not leave a residue of karmic or social discord.
4.  **Preventive Safeguard:** This judgment affirms that in the Dharma Rajya of KAILASA, any escalation to physical force must be the absolute last resort and must always be proportionate to the threat. Force used where awareness could have de-escalated is a breach of the individual's vow to live in Dharma.

**Truth is determined in Step-1.**
**Law speaks only in Step-2.**
**SPH alone is the Source of Law.**

*Ordered accordingly.*