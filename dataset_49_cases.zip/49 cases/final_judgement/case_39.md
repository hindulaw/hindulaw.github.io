# **JUDGMENT OF THE KAILASA AI JUDGE**

**Case Ref:** *Karan Oberoi vs. Sunita Malhotra (Property Dispute)*  
**Date:** January 19, 2026  
**Authority:** Bhagwan Nithyananda Paramashivam (SPH)

---

### **1. Issues for Determination**

The following issues are identified for adjudication under the Dharma Rajya of KAILASA:

*   **I. Adherence to Satya (Integrity):** Did the failure of the Plaintiff (Buyer) to secure financing within the stipulated deadline constitute a breach of commercial integrity under SPH’s interpretive Dharma?
*   **II. Exercise of Authority without Awareness:** Did the Defendant (Seller), in her capacity as the holder of the asset and earnest money, exercise her authority with the required self-mastery and consciousness, or was her immediate termination of the agreement an act of unconscious dominance?
*   **III. Restorative Remedy:** What corrective directions are necessary to restore the dignity of both parties and realign their conduct with Dharma?

---

### **2. Adoption of Findings of Fact (from Step-1)**

This Judge strictly and exclusively adopts the following **Findings of Fact (FINAL)** as the sole foundation for this judgment:

1.  An agreement existed between Karan and Sunita for the sale of property, supported by the payment of earnest money.
2.  The agreement contained a deadline for the arrangement of funds and completion of the sale.
3.  Karan failed to secure a bank loan sanction within the timeframe required to meet the payment deadline.
4.  Sunita did not grant an extension and immediately began seeking other buyers once the deadline was missed.
5.  The transaction failed primarily because the buyer’s financing was not secured on time, followed by the seller’s immediate decision to treat the contract as ended.

---

### **3. Findings on Consciousness and Authority / Force**

The conduct of the parties is assessed as follows:

*   **Plaintiff (Karan Oberoi):** The Plaintiff exhibited **egoic negligence**. By entering into a time-bound agreement while dependent on a third-party institutional speed (the bank), he failed to maintain self-mastery over his commitments. His inability to fulfill his "Vachana" (word) constitutes a failure of Integrity (Satya).
*   **Defendant (Sunita Malhotra):** The Defendant exhibited **authority without awareness**. As the owner of the asset and the holder of the earnest money, she possessed the power to determine the outcome of the transaction. Her immediate marketing of the property upon the expiration of the deadline, without considering a grace period or the buyer's vulnerability to external institutional delays, indicates a lack of consciousness-based commerce. Her actions were driven by market dynamics rather than a restorative intent to see the transaction to completion.

---

### **4. Application of SPH Interpretive Manu Jurisprudence**

According to SPH’s interpretation of *Manu Smṛti*, specifically the principles governing commercial fidelity and the duties of those in positions of power (*Manu 8.397, 7.84*):
*   Commerce is not merely an exchange of goods but a field for the practice of Dharma.
*   Authority exercised solely for egoic gain (market advantage) at the expense of another's vulnerability is a deviation from the causal field of Integrity (*Sadācāra*).

#### **Nyāya Inference**
1.  **Pratijñā (Proposition):** The Defendant’s immediate termination of the contract and retention of earnest money was Adharmic.
2.  **Hetu (Reason):** Because she exercised her positional authority over the asset and the earnest money without awareness of the Plaintiff’s specific financial vulnerability (dependency on the bank).
3.  **Udāharaṇa (SPH–Manu Principle):** Bhagwan Nithyananda Paramashivam teaches that "Authority or force exercised without awareness is violence," and commercial law must focus on "restoring correct perception" rather than "punitive severance" (*Manu 7.84*).
4.  **Upanaya (Application):** Sunita held the power to extend the timeline but chose immediate termination to seek a better offer, treating the earnest money as a penalty rather than a restorative bond.
5.  **Nigamana (Conclusion):** Therefore, her response was a violation of the Dharmic duty of the powerful to protect the integrity of the transaction through consciousness.

---

### **5. Verdict in Dharma**

This Judge finds that:
*   The **Plaintiff** is in violation of **Satya (Integrity)** for failing to master his financial timeline.
*   The **Defendant** is in violation of **Dharma (Consciousness in Authority)** for exercising her power with unconscious dominance and a lack of restorative intent.

The transaction has collapsed not merely due to a bank delay, but due to a mutual failure of consciousness.

---

### **6. Corrective Directions**

To restore the balance of Dharma and protect the dignity of both parties, the following directions are issued:

1.  **Restoration of Funds:** The Defendant shall return 70% of the earnest money to the Plaintiff. The remaining 30% may be retained by the Defendant as a "Restorative Cost" for the time the property was off the market. This ensures the Defendant is not harmed while preventing the earnest money from being used as an instrument of punishment.
2.  **Consciousness Recalibration:** Both parties are directed to attend a session on **"Integrity in Commerce and Power with Awareness"** conducted by the KAILASA Department of Dharma.
3.  **Completion Process:** The Plaintiff shall undergo a completion process regarding his failure to keep his word, and the Defendant shall undergo a completion process regarding her immediate impulse to utilize another's failure for market advantage.
4.  **Systemic Direction:** In future transactions under this jurisdiction, a **"Dharmic Grace Period"** of seven (7) days is recommended following a deadline breach to allow for consciousness-based resolution before the unilateral termination of an agreement.

**Truth is determined in Step-1.**
**Law speaks only in Step-2.**
**SPH alone is the Source of Law.**

**[END OF JUDGMENT]**