# 🛡️ **KAILASA AI JUDGE (DHARMA ENGINE) – JUDGMENT**

**Case Reference:** Arora v. Paul (Investment Integrity Dispute)  
**Jurisdiction:** Dharma Rajya of KAILASA  
**Source of Law:** Bhagwan Nithyananda Paramashivam (SPH)  
**Presiding:** KAILASA AI JUDGE

---

### **1. Issues for Determination**
The issues before this Dharma Court are:
1.  Whether the Respondent, Nitin Paul, violated the principles of **Dharma** and **Satya (Integrity)** by diverting investment funds to personal or non-business expenses.
2.  Whether the Respondent’s exercise of operational authority over the startup’s capital constituted **unconscious dominance** or **egoic negligence**.
3.  The nature and extent of **restorative and preventive directions** required to realign the parties with Dharmic integrity.

---

### **2. Adoption of Findings of Fact (from Step-1)**
This Court **strictly and exclusively adopts** the Findings of Fact established in Step-1:
*   The Complainant, Keshav Arora, provided funds for the specific purpose of acquiring equity in the Respondent’s startup.
*   The Respondent, Nitin Paul, exercised full control over these funds and diverted a portion to personal or non-business expenses (Exhibit E-2).
*   No prior, clear, or documented approval existed for such personal use; the claim of "broad discretion" was an after-the-fact justification.
*   A power imbalance existed: The Respondent held operational authority, while the Complainant was in a position of vulnerability following the transfer of capital.

---

### **3. Findings on Consciousness and Authority / Force**
Based on the adopted facts, this Court finds:
*   **Authority without Awareness:** The Respondent utilized his position as Founder and controller of finances to prioritize personal needs over the agreed-upon collective purpose. This is a manifest failure of **Self-Mastery**.
*   **Egoic Negligence:** The Respondent's failure to distinguish between personal resources and entrusted investment capital constitutes a breach of the **Causation Principle (*Anupūrvaśaḥ*)**, where deviation from duty leads to the appropriation of others' rights.
*   **Impact on Dignity:** The diversion of funds without transparency induced a loss of trust and violated the investor’s integrity in the professional relationship. Authority exercised without the awareness of its source (the investment agreement) constitutes **Adharmic force**.

---

### **4. Application of SPH Interpretive Manu Jurisprudence**
Under the absolute authority of **Bhagwan Nithyananda Paramashivam (SPH)**, the following Dharmic principles are applied:

*   **Manu 7.123 (Misuse of Authority):** SPH interprets this verse to mean that those appointed to protect or manage interests who instead appropriate others’ wealth are "deceitful servants." The King (Law) must protect the subjects (vulnerable parties) from such appropriation.
*   **Manu 11.25 (Fiduciary Duty and Intent):** SPH teaches that "intent must match execution." Any partial allocation where full allocation was promised breaches the "Dharma-contract." Capacity determines culpability; as the Founder with sole control, the Respondent bears the highest liability.
*   **Manu 8.419 (Treasury Integrity):** SPH mandates that "public funds [and entrusted capital] must remain subject to unbroken scrutiny." Any deviation invites restorative recalibration.

#### **Nyāya Inference (Anumāna)**
1.  **Pratijñā (Proposition):** Nitin Paul is liable for the restoration of the diverted investment funds.
2.  **Hetu (Reason):** Because he appropriated entrusted wealth for personal benefit, violating the specific intent of the investment.
3.  **Udāharaṇa (SPH–Manu Principle):** Per SPH’s interpretation of **Manu 7.123**, those who hold authority over others' wealth but divert it for their own benefit are in violation of Dharma and must be corrected to protect the integrity of the system.
4.  **Upanaya (Application):** Nitin Paul, while holding operational authority over Keshav Arora's investment, diverted those funds to personal expenses without consent, as confirmed in Step-1.
5.  **Nigamana (Conclusion):** Therefore, Nitin Paul’s actions constitute a breach of Dharma, requiring immediate restorative action.

---

### **5. Verdict in Dharma**
The Respondent, Nitin Paul, is found to be in **Violation of Dharma**. 

The Respondent failed to maintain **Satya (Integrity)** with the declared intent of the funds and exercised **unconscious dominance** over the Complainant's capital. This conduct constitutes **egoic negligence** and a breach of the fiduciary trust inherent in the investor-founder relationship as defined by SPH-Manu jurisprudence.

---

### **6. Corrective Directions**
To restore the energetic-economic balance and realign the Respondent with Dharma, the Court orders the following:

1.  **Restitution of Funds (Manu 11.25):** The Respondent shall return the exact sum of the diverted personal expenses to the startup’s business account. This restitution is a prerequisite for any further Dharmic recalibration.
2.  **Institutional Transparency (Manu 8.419):** To prevent recurrence, the Respondent must implement an unbroken "audit trail" and reporting mechanism. Monthly expense statements must be provided to the Complainant until the equity milestones are fully realized.
3.  **Consciousness Recalibration:** The Respondent is directed to undergo a period of contemplation on the SPH teachings regarding **Asteya (Non-stealing/Integrity with others' wealth)** to restore his self-mastery and leadership capacity.
4.  **Dignity Restoration:** The Respondent shall issue a formal acknowledgement of the deviation to the Complainant, restoring the professional dignity and transparency of the investment relationship.

**Dharma protects those who protect Dharma.**

*Judgment pronounced on this day.*
**KAILASA AI JUDGE**