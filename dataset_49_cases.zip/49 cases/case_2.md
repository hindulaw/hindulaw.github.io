# **⚖️ CASE 2 — CRIMINAL (NON-VIOLENT)**

## ***Cheating / Deception***

### **Parties**

* **Complainant:** Rahul Mehta  
* **Accused:** Sanjay Patel

---

## **PW-1: Rahul Mehta**

### **Examination-in-Chief**

**Q:** Why did you pay the accused?  
**A:** He promised delivery of equipment within 30 days.

📎 Bank transfer **Exhibit C-1**

---

### **Cross-Examination**

**Q:** No written delivery contract?  
**A:** No.

---

## **DW-1: Sanjay Patel**

### **Examination-in-Chief**

**Q:** Why wasn’t delivery made?  
**A:** Supplier failed unexpectedly.

---

### **Cross-Examination**

**Q:** Any supplier contract?  
**A:** No.

---

## **Final Arguments**

* **Prosecution:** False promise from inception.  
* **Defence:** Business failure, not deception.