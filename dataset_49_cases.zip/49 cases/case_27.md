# ⚖️ CASE 27 — FAMILY & PERSONAL RELATIONS

## *Relocation Dispute*

### Parties

* **Parent A:** Meenal Shah
* **Parent B:** Harish Shah

### Facts

Meenal plans to relocate for employment with the child; Harish opposes citing reduced access.

### Evidence

* Job offer letter (Exhibit F-1)
* Proposed visitation plan (Exhibit F-2)

### Witnesses

* **PW-1:** Meenal
* **PW-2:** Employer HR (confirms offer)
* **PW-3:** Harish

### Trial Highlights

* **Cross of Meenal:** Acknowledges fewer in-person visits.
* **Cross of Harish:** Admits flexible work hours.

### Final Arguments

* **Meenal:** Economic stability benefits child.
* **Harish:** Relationship disruption outweighs benefit.
