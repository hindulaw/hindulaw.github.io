# **⚖️ CASE 5 — PROPERTY & CONTRACT**

## ***Breach of Contract***

### **Parties**

* **Zenith Builders vs Coastal Suppliers**

---

## **PW-1: Project Manager**

### **Examination-in-Chief**

**Q:** Impact of delay?  
**A:** Project loss and penalties.

📎 Contract **Exhibit C-1**

---

### **Cross-Examination**

**Q:** Force majeure clause exists?  
**A:** Yes.

---

## **DW-1: Supplier Director**

### **Examination-in-Chief**

**Q:** Cause of delay?  
**A:** Supply chain disruption.

---

## **Final Arguments**

* **Plaintiff:** Delay unjustified.  
* **Defendant:** External disruption excused.