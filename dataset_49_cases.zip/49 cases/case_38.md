# ⚖️ CASE 38 — PROPERTY & CONTRACT

## *Quality vs Acceptance*

### Parties

* **Plaintiff:** Vertex Manufacturing
* **Defendant:** Omega Distributors

### Facts

Vertex claims Omega accepted goods without objection and later alleged defects to avoid payment. Omega claims defects discovered during use.

### Evidence

* Delivery receipts (Exhibit P-1)
* Complaint emails (Exhibit D-1)

### Witnesses

* **PW-1:** Vertex QA Manager
* **DW-1:** Omega Operations Lead

### Trial Highlights

* **Cross of DW-1:** Delay of 30 days before complaint.
* **Cross of PW-1:** No joint inspection done.

### Final Arguments

* **Plaintiff:** Acceptance bars later rejection.
* **Defendant:** Latent defects justify objection.