# ⚖️ CASE 39 — PROPERTY & CONTRACT

## *Agreement to Sell — Earnest Money Dispute*

### Parties

* **Plaintiff:** Karan Oberoi
* **Defendant:** Sunita Malhotra

### Facts

Karan seeks refund of earnest money alleging seller backed out. Sunita alleges buyer failed to arrange funds by deadline.

### Evidence

* Agreement to sell (Exhibit P-1)
* Bank correspondence (Exhibit D-1)

### Witnesses

* **PW-1:** Karan
* **DW-1:** Sunita

### Trial Highlights

* **Cross of Karan:** Loan sanction letter came late.
* **Cross of Sunita:** Property marketed to others soon after.

### Final Arguments

* **Plaintiff:** Seller acted in bad faith.
* **Defendant:** Buyer defaulted first.
