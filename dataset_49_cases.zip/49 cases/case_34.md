# ⚖️ CASE 34 — PROPERTY & CONTRACT

## *Termination Clause Misuse*

### Parties

* **Plaintiff:** BrightTech Solutions
* **Defendant:** OmniServices

### Facts

BrightTech alleges OmniServices terminated a services contract to avoid payment after milestones were met. OmniServices claims poor performance.

### Evidence

* Milestone reports (Exhibit P-1)
* Termination notice (Exhibit D-1)

### Witnesses

* **PW-1:** BrightTech Project Lead
* **DW-1:** OmniServices Program Manager

### Trial Highlights

* **Cross of DW-1:** No cure notice issued.
* **Cross of PW-1:** One milestone delayed by a week.

### Final Arguments

* **Plaintiff:** Termination pretextual.
* **Defendant:** Contractual right exercised.
