# **⚖️ CASE 7 — MIXED / EDGE CASE**

## ***Consent Later Disputed***

### **Parties**

* **Priya Sen vs Aman Khanna**

---

## **PW-1: Priya Sen**

### **Examination-in-Chief**

**Q:** Why dispute consent now?  
**A:** Financial pressure during relationship.

📎 Messages **Exhibit C-1**

---

### **Cross-Examination**

**Q:** Messages show agreement?  
**A:** Under emotional pressure.

---

## **DW-1: Aman Khanna**

### **Examination-in-Chief**

**Q:** Were decisions mutual?  
**A:** Yes.

---

## **Final Arguments**

* **Complainant:** Consent vitiated by pressure.  
* **Defence:** Voluntary participation.