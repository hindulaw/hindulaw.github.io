# ⚖️ CASE 17 — CRIMINAL (NON-VIOLENT)

## *Repeated Assurances, No Action*

### Parties

* **Complainant:** Sunil Grover
* **Accused:** Ritu Malhotra

### Facts

Ritu repeatedly promised delivery “next week” for months after taking payment.

### Evidence

* Repeated assurance messages (Exhibit P-1)

### Witnesses

* PW-1 Sunil
* DW-1 Ritu

### Trial Highlights

* **Cross of DW-1:** No concrete delivery steps taken.

### Final Arguments

* **Prosecution:** Pattern shows deceptive intent.
* **Defence:** Operational delays, not deceit.
