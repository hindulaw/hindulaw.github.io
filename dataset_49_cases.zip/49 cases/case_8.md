# **⚖️ CASE 8 — CIVIL / SERVICE & EMPLOYMENT**

## ***Unequal Workload Allocation***

### **Parties**

* **Complainant:** Ritesh Malhotra, Senior Analyst  
* **Respondent:** Kavita Deshmukh, Department Head

### **Complaint (Raw)**

Ritesh alleges he was assigned disproportionately heavy workloads compared to peers, leading to burnout. Claims assignments increased after he questioned timelines.

### **Response**

Kavita states workload was skill-based, not punitive.

### **Evidence**

* Task allocation spreadsheets (Exhibit C-1)  
* Internal emails (Exhibit C-2)

### **Witnesses**

* PW-1 Ritesh  
* PW-2 Co-worker  
* DW-1 Kavita

### **Trial Highlights**

* PW-1 testifies to repeated overload  
* Cross shows no formal workload policy  
* DW-1 admits no rotation system

### **Final Arguments**

* **Complainant:** Unequal burden used as pressure tool  
* **Respondent:** Managerial discretion, no intent
