# ⚖️ CASE 22 — CRIMINAL (VIOLENT / THREAT)

## *Domestic Physical Incident (Minor Injury)*

### Parties

* **Victim:** Kavya Rao
* **Accused:** Mohan Rao

### Facts (Complaint)

During a domestic argument, Kavya alleges Mohan grabbed her arm and pushed her, causing a bruise. Mohan claims he tried to leave the room and contact was accidental.

### Evidence

* Photo of bruise (Exhibit P-1)
* Text messages exchanged same night (Exhibit P-2)

### Witnesses

* **PW-1:** Kavya Rao
* **PW-2:** Neighbor (heard shouting)
* **DW-1:** Mohan Rao

### Trial Highlights

* **PW-1 (Chief):** Describes push and pain.
* **Cross:** Admits argument was mutual; no medical visit.
* **DW-1 (Chief):** Claims accidental contact.
* **Cross:** Admits raised voice and blocking doorway briefly.

### Final Arguments

* **Prosecution:** Physical contact + bruise establishes force.
* **Defence:** Accident during argument; no intent to harm.