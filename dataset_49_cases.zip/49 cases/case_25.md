# ⚖️ CASE 25 — FAMILY & PERSONAL RELATIONS

## *Sole Custody vs Shared Custody*

### Parties

* **Parent A:** Ananya Mehta
* **Parent B:** Kunal Mehta

### Facts

Separated parents dispute custody of a 6-year-old. Ananya seeks sole custody citing routine and schooling; Kunal seeks shared custody citing strong bond.

### Evidence

* School attendance records (Exhibit F-1)
* Parenting schedules (Exhibit F-2)

### Witnesses

* **PW-1:** Ananya
* **PW-2:** Teacher
* **PW-3:** Kunal

### Trial Highlights

* **Teacher:** Child performs well but shows anxiety after transitions.
* **Cross of Ananya:** Admits limiting mid-week access.

### Final Arguments

* **Ananya:** Stability paramount.
* **Kunal:** Balanced involvement benefits child.
