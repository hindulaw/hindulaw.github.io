# ⚖️ CASE 35 — PROPERTY & CONTRACT

## *Rental Possession Conflict*

### Parties

* **Plaintiff:** Landlord—Seema Arora
* **Defendant:** Tenant—Vivek Jain

### Facts

Seema seeks possession alleging unpaid dues. Vivek claims payments adjusted against repairs.

### Evidence

* Rent ledger (Exhibit P-1)
* Repair receipts (Exhibit D-1)

### Witnesses

* **PW-1:** Seema
* **DW-1:** Vivek
* **PW-2:** Repair contractor

### Trial Highlights

* **Contractor:** Repairs done; payment delayed.
* **Cross of Vivek:** No written adjustment agreement.

### Final Arguments

* **Plaintiff:** Non-payment established.
* **Defendant:** Equitable adjustment warranted.
