# ⚖️ CASE 24 — CRIMINAL (VIOLENT / THREAT)

## *Accidental Injury Dispute*

### Parties

* **Victim:** Neha Kulkarni
* **Accused:** Arvind Kulkarni

### Facts

During a heated discussion, a door slammed; Neha’s finger was injured. Neha alleges Arvind slammed intentionally; Arvind claims accident.

### Evidence

* Injury photo (Exhibit P-1)
* Audio message sent later (Exhibit D-1)

### Witnesses

* **PW-1:** Neha
* **DW-1:** Arvind

### Trial Highlights

* **Cross of PW-1:** No eyewitness.
* **Cross of DW-1:** Acknowledges anger at the time.

### Final Arguments

* **Prosecution:** Anger + timing implies intent.
* **Defence:** No direct act toward injury.
