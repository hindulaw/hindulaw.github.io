# ⚖️ CASE 31 — FAMILY & PERSONAL RELATIONS

## *False Accusation Within Family*

### Parties

* **Complainant:** Kiran Patel
* **Respondent:** Mahesh Patel

### Facts

Kiran alleges Mahesh spread false claims affecting reputation during inheritance talks. Mahesh claims statements were concerns, not accusations.

### Evidence

* Family chat excerpts (Exhibit F-1)
* Meeting notes (Exhibit F-2)

### Witnesses

* **PW-1:** Kiran
* **PW-2:** Family mediator
* **DW-1:** Mahesh

### Trial Highlights

* **Mediator:** Discussions were heated; wording ambiguous.
* **Cross of Mahesh:** Admits repeating unverified claims.

### Final Arguments

* **Kiran:** Reputation harmed by false statements.
* **Mahesh:** Opinion expressed without malice.
